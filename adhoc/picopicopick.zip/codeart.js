// remember to escape all backslashes
var codeart = [
{"title":"",
        "date":"",
        "desc":"",
        "art":"",
        "code":``},
{"title":"Dark Ages",
        "date":"2025-07-09",
        "desc":"The first couple of nights after they cut the power were just scary. Then the looting and burning began. Streets in flames. And that smell. You didn’t have to die to go to hell.",
        "art":"night-houses-6_1.gif",
        "code":`local v,r,s,t,c,k=0::_::l=line?"\\^1\\^c7\\^!5f11██🐱░49:♥7"
v+=.03for y=0,176do
srand(y)--v\\.1333)
c=rnd(160)r=rnd(32)+16s=abs(sin(v+r))/19+.9for j=0,r do
if(j<9)k=y-j-r+5t=9-abs(j+j-9)l(c-t,k,c+t+1,k,0)
l(c-9,y-j,c,y-j+4,max(8-j/4*s))l(c+9,y-j)end
l(c,y-r,c,y-r-8,0)end
goto _`},
{"title":"Spring",
		"date":"2025-03-21",
		"desc":"The problem with synthoids was that they simply thought too much, overly fixated on optimization. The organics played the long game, dancing patiently since the dawn of time.",
		"art":"ivy-v3-5_3.gif",
		"code":`X=0Y=0L=1
function f(x,y,g,l,d,p,q)
C+=1
u=sin(g)v=cos(g)k=min(l,8)
p,q=x+u*k,y-v*k
for i=1,k do 
srand(x\\1*128+y\\1+i)
r=.85
if(d>6 or C>150)r=1
if(d<=0and i>7)r=0
h=rnd(.6)-.3
circ(p+i*u,q-i*v,i/5,i/2)
j=i/6
line(x-v*j,y+u*j,p-v*j,q+u*j,min(l/8,3)+i/2)
if(rnd()>r)f(p,q,(g+h)/2,l-i,d+rnd(r*2))
end
if(L<0and y<n-128)L=32U=x-X-64V=y-Y-127
end
::_::
?"\\^1\\^cd\\^!5f11⌂⬅️3⬇️🐱░49"
camera(X,Y)
L-=1
if(L>0)X+=U/32Y+=V/32
if(L==0)m=X+64n=Y+128s=0
if(L<0)s+=1
C=0
f(m,n,0,s,0)
goto _`},
{"title":"Genuary 25",
		"date":"2025-02-01",
		"desc":"One line that may or may not intersect itself",
		"art":"genuary2025-25-3_0.gif",
		"code":`p={}
x=64
y=64
a=0
g=0
h=0
::_::
?"\\^1\\^c0\\^!5f11▒⬇️3⬅️;⌂:♥"
for k in all(p)do 
pset(k[1],k[2],min(pget(k[1],k[2])+1+max(k[3]),8))
k[3]-=1
k[1]-=k[5]
k[2]+=k[4]
end
for i=1,80do
if(#p>128*8)deli(p,1)
u=cos(a)/2
v=sin(a)/2
x=(x+u)%127
y=(y+v)%127
if(rnd()<.1)g=rnd()
h-=1
if(h>0)g=a-0.6
a-=(((a-g+.5)%1)-.5)/20
add(p,{x,y,h,u,v})
if(h<=-30and pget(x+u*4,y+v*4)>0)h=30
end
goto _`},
{"title":"Infinite scroll / Genuary 28",
		"date":"2025-01-30",
		"desc":'The altar was surrounded by countless skeletons. Above it, the scroll of immortality floated silently. What does it say? "Thou shall die if ye cease reading!" Oh, no!',
		"art":"genuary2025-28-10_0.gif",
		"code":`fillp(▒\\1)r=rnd::_::?"\\^1\\^c0\\^!5f11█✽●?"
for a=0,1,.0033do
y=64+cos(a)\\.03+sin(t()/4)\\.5srand(t()\\.1+y)x=48+8*sin(a+a)+r(2)k=min(4,2+sin(a)^2*6)/(2-a\\.5)if(y~=l)line(x,y,x+32,y,k+(k+.5)\\1*16)l=y
x+=6if(r()<.1)for i=0,32do x+=r()pset(x,y-6+r(6),max(pget(x,y)-1))end
end
goto _`},
{"title":"Symmetry / Genuary 26",
		"date":"2025-01-27",
		"desc":"You can hear the pagans across the river, yelling like demons around their bonfires. Oh, how you wish you could join them. Their euphoria is as vast as your dogmatic sorrow.",
		"art":"genuary2025-26-4_1.gif",
		"code":`r=rnd::_::srand()?"\\^1\\^c0\\^!5f11⬇️3;0█░4"
for i=0,720do
x=20+i/8if(i%8<1)z=r(8)d=abs(64-x)?"|",x,59,4+r(3)*(1-d/99)
circ(x+r(4),56-z+r(6),1,3-d/16+r(2))pset(59+x/48,64-z-(t()+i)%7,r(4)+7)x+=r(8)q=64+i%16k=pget(x,128-q)f=sin(t()/2+i/99)*3line(x-f,q,x+f,q,k-min(k%4,1))end
goto _`},
{"title":"Op-Art / Genuary 19",
		"date":"2025-01-22",
		"desc":"",
		"art":"genuary2025-19-C-4_2.gif",
		"code":`local u,v,x,y,z,c,w,d::_::?"\\^1\\^c0\\^!5f11☉⬅️♥😐><"
h=t()
for o=0,2do
poke(24414,(1<<o)+0xf0)
for a=0,1,.001 do
d=sin(h/8+o/25)
u=cos(a+h/6+d/8)
v=sin(a)
w=cos(d+2*a)
z=sin(d+2*a+h/8)
x=64+u*(48+d*8)
y=64+z*(16+d*16)
if((a<<8)&8>0)z=-z u=-u
line(x,y,x-z*8,y+u*8,7)
end
end
goto _`},
{"title":"What does wind look like? / Genuary 18",
		"date":"2025-01-20",
		"desc":"",
		"art":"genuary2025-18-7_5.gif",
		"code":`function g(x,y,a,b,d,p,q)p=x+d*cos(a-b)q=y+d*sin(a-b)for i=-d,d,16do
line(x+i/24,y,p+i/32,q)if(rnd()<d/16)g(p,q,a+i/rnd{-1,1}*.004,b*(1.2+d/64),d*.7)end
m+=3poke4(m,$m%256+rnd(6)+2)?".",$m,m/3%99
end::_::m=0?"\\^1\\^c0"
srand()g(50,99,.2,sin(t()/2)*(1+sin(.1-t()/3)/2)/64,30)goto _`},
{"title":"Neo-Tokyo Circular Route",
		"date":"2025-01-16",
		"desc":"He could hear the highway, but his visor was cracked, and all he could see was a kaleidoscope of lights and the shadows of passing cars.\n\n(Pure black and white. No gray / Genuary 14)",
		"art":"genuary2025-14-5_0.gif",
		"code":`b=7c=0d=.5
::r::
a,b,c,d={},c,b,d+.5
cls(b)
::_::
if(rnd(2)<#a+4)add(a,{rnd(128),rnd(128),rnd(),2})
if(#a>128)goto r
for i=1,4 do
for l in all(a)do
l[1]+=cos(d)/8
l[2]+=sin(d)/8
l[3]+=.0003
l[4]*=1.02
x=l[1]
y=l[2]
u=cos(l[3])*l[4]
v=sin(l[3])*l[4]
line(x+u,y+v,x-u,y-v,c)
end
end
flip()
goto _`},
{"title":"Visual Calculus",
		"date":"2025-01-15",
		"desc":'"In the photo of your missing brother... this rug was on the wall, wasn’t it?"\n"Yes, detective. But I’ve redecorated," he said - and used it to cover his blood, he thought.\n\n(Design a rug / Genuary 15)',
		"art":"genuary2025-15-9_0.gif",
		"code":`::_::d=-44*sin(t()/8)?"\\^1\\^c0\\^!5f11🐱░49"
srand(1)for x=64,2,-1do
pset(x,rnd(48)+31,rnd{2,8})for y=-1,63do
k=y-x&x+y
c=(x<7or x>119)and y&1or(x<16or x>110or y<8or y>54)and(k&1)+2+max(x&7,y&7)\\7or(k&6)+2>>1u=x
pset(126-u,y+32,c)if(u+y<d)u,y=d-y,d-u
pset(u,y+32,c)end
end
goto _`},
{"title":"Remuneration",
		"date":"2025-02-01",
		"desc":'He delivered, so they paid him with gold as agreed. However, it was a four-dimensional gold nugget, and we didn’t have the technology to unpack it.\n\n(Vertical or horizontal lines only / Genuary 7)',
		"art":"genuary2025-1-7_1.gif",
        "code":`::_::
?"\\^1\\^c0\\^!5f11██🐱░49:♥7"
for y=0,127,2do
for f=-1,1,2do
line(64,y,64,y,0)
k=64
for x=0,127,16do
u=x/512*f+t()/8v=y>>8g=v
e=0for i=1,3do g*=2e+=.7^i*(sin(g*u/v/2+sin(g/2)/2)+sin(g))end
d=abs(e)*2
line(k,y,k+d*f-f-f,y,d+d)
k+=d*f
end
end
end
goto _`},
{"title":"Long live the New Flesh",
        "date":"When Max Renn uttered his final words and shot himself, it wasn't an act of consecration or communion. It was merely content, played in an endless loop and fed to the hungry masses.",
        "desc":"2024-11-28",
        "art":"tape-2_1.gif",
        "code":`::lltnf::
?"\\^1\\^c0\\^!5f1d😐"
x=-32
y=40+sin(t()/4)*8
a=.75
for i=0,1.6,.002 do
f=1-mid(i*2-.8,1)
if(i<1)a=.9*f+(cos(sin(t()/6+i))*(.3+i)/5+1.4)*(1-f)
if(i>1)a+=(atan2(32-x+sin(t()/4)*32,-10-y)-a%1)/19
x+=cos(a)/2
y+=sin(a)/2
for j=0,11 do
pset(x+j/4,y-j,8+j/2)
end
end
goto lltnf`},
{"title":"Lesson learned",
        "date":"2024-11-21",
        "desc":"It was being melted down, and these were the final moments of its existence. It didn't despair but, with futile diligence, analyzed the decision tree to understand its mistakes",
        "art":"melt-6_3.gif",
        "code":`r={}s=0
for i=0,160do r[i]={rnd(128),i-16,10}end
::_::
?"\\^1\\^c7\\^!5f11█░4웃9:♥7"
for j=0,#r-1 do
i=(j+s)%#r
b=r[i]
b[2]+=1
if(b[2]>144)b[3]=12b[2]=-16s=i
x=b[1]
y=b[2]
d=mid(8,b[3]-(y/128)^2*16)
if(d>0)for i=6,max(0,3-d),-1 do ovalfill(x-d*3,y+i+d,x+d*3,y+i-d,i)end
end
goto _`},
{"title":"Spark",
        "date":"2024-11-07",
        "desc":"The plasma globe at the flea market hums quietly. Beams dance under your fingertips. It looks just like the one you had years ago-until your brother smashed it. And laughed. Now, you hate this lamp.",
        "art":"electric-ball-5_0.gif",
        "code":`r=rnd::_::?"\\^!5f11▒1😐<7"
b=r()<cos(r())u=0v=0g=r()for d=0,1,.0004do 
a=r()x=64+d*33*sin(a)y=64+d*33*cos(a)c=d^8*(2+r(2))+.2\\d
e=pget(x,y)if(e>c)c=e-1 
pset(x,y,c)d=(u*u+v*v)>>10if(b and d<1)u+=sin(g)/3v+=cos(g)/3g+=r(-1)>>(20.5-d)pset(u+64,v+64,(pget(u+64,v+64)+1+d)&7)end
goto _`},
{"title":"Two kinds of people",
        "date":"2024-10-18",
        "desc":'"Oi, Hack-boy" Ape looks at you, "you done?" He steps over the guard, fist capacitors whining as they charge. Hell no, you\'re not done-because every time you delete the footage, some backup mechanism restores it.',
        "art":"squares-2_2.gif",
        "code":`j=0
::_::
?"\\^1\\^c0\\^!5f11█🐱░49:♥7"
for i=16,47 do
x=i%8*16+1
y=i\\8*16
m=mid(16,j-i)
if(j-i<16)rectfill(x+m,y+m,x+13-m,y+13-m,mid(8-j+i,7))
n=mid(13,j-i-16)
if(j-i>16)rectfill(x,y,x+n,y+n,max(m/2-1))m-=16
rect(x+8-m/8,y,x+15,y+m,0)
end
j+=.5
if(j>99)j=0
goto _
`},
{"title":"Epilogue",
        "date":"2024-08-25",
        "desc":"Each time the god-emperor shed his glittering skin, a century of reforms began. But when he started losing his golden hair, the people instantly knew that a dark era was ahead.",
        "art":"falling-lines-3_0b.gif",
        "code":`r=rnd::_::?"\\^1\\^c0\\^!5f11█🐱░49:♥777"
for i=0,22500,20do
local x,y,l,o,s=peek4(i,5)local p,q,u,v=x,y,cos(o),sin(o)for l=0,l do
pset(p,q,pget(p,q)+1)p+=u
q+=v
end
y+=s+y/32o-=s*y/4000if(y>128+l)y=1o=0
if(y<1)y=r(64)x=r(160)-16l=8+r(8)o=y/999s=r()
poke4(i,x,y,l,o,s)end
goto _`},
{"title":"Alzheimer",
        "date":"2024-08-23",
        "desc":"Be very, very careful because it always starts with the little things. Then its gettting worse and wars und ouy cunt member, dismember this, ths f..fukng... Oh, hello.",
        "art":"tiles-7_8.gif",
        "code":`r=32o={}q={}for i=0,1024do o[i]=i q[i]=6end
q[528]=0::_::?"\\^1\\^c0"
for i=0,1024do
j=o[i]t=j%1*9c=q[i]j\\=1k=i+rnd{-1,1,-r,r}if(q[k]==0and j==i)q[k]=-1j=k
if(j~=i)t+=.2
x=i\\r+t*(j\\r-i\\r)y=i%r+t*(j%r-i%r)if(c>0)?"■",x*4,y*4,c
if(t>1)q[j]=rnd(16)\\1t=0q[i]=0j=i
o[i]=j+t/9end
goto _`},
{"title":"Escape from New York",
        "date":"2024-07-10",
        "desc":"- Are you picking up the target blip?<br>- Right on course. Been a while.<br>- How's your altitude?<br>&nbsp;&nbsp;Plissken. Plissken?<br>&nbsp;&nbsp;Plissken, what are you doing?<br>- Playing with myself. I'm going in.",
        "art":"plissken-7_2.gif",
        "code":`::_::?"\\^1\\^c0\\^!5f11▒⬇️3⬅️;⌂"
if(t()<3)x=rnd(16)y=rnd(16)sset(x,y,2-14*cos(x/32)^4)
for v=75,127do
z=2560/(v-64)
d=z/32
w=400/z
x=z
for u=0,127,2do
x-=d
c=w*sget((x/20+8)&15,(z/20+t()*2)&15)if(c>0)k=v/8-9rect(u,v+32,u+1,v-c,k)for y=v-c+9,v,w*3do pset(u,y,k+1)end
end
end
goto _`},
{"title":"Agony Again",
        "date":"2024-02-02",
        "desc":"A humble homage to 1992 Amiga classic game <br>(a Lovebyte 2024 party entry for 256b intro)",
        "art":"rostok-lb24-14p8_1.gif",
        "code":`function
f(d,f,n,i)
for
o=0,1,.01do
circ(d+n-n*o,f+i-i*o,3*o^█,█+o+o+o+o+o+(1+o+o+o+o+o)\\1*16)end
end
::o::d=5*sin(t())srand(128)
?"⁶1⁶c6⁶!5f31𝘻𝘻"
for
o=0,1,.01do?".⁶!5f11🐱♪=67✽",(rnd(128)-28*(1+o)*t())%128,rnd(128),1+o+o+o
end
f(65,65-d,-34,5+d*█)
f(65,65-d+3,-34,2+d*█)
f(65,65-d+1,0,0)
for
o=0,5do
f(63,65-d+d*o,sin(o/10)*8-20,0)
end
for
o=0,9do
f(63,65-d+d*4,sin(o/20)*8-cos(o/30)*8*3,sin(o/30)*8*5*sin(t()+.3))
end
goto
o`},
{"title":"Critter",
        "date":"2024-02-08",
        "desc":"You always felt something observing you at your grandparents' house. But this time, you saw it yourself. <br>(a tweetcart version of Lovebyte 2024 party entry for 256b tiny exe gfx)",
        "art":"lovebyte2024-critter-9-single-tweet-2_1.gif",
        "code":`?"⁶c0⁶!5f11▒⬇️3⬅️;⌂:2☉"
srand(71)for
o=0,1999do
if(o<20)?"¹d░",1
f=rnd(144)-8n=rnd(144)-8if((f-84)^2+(n*1.1-99)^2<500)f=144
e=rnd(.2)+.4for
o=0,12,.5do
for
d=5*sin(o/24),-5*sin(o/24),.5do
c=f+d*cos(e)r=n+o+d*sin(e)pset(c,r,rnd(2)+3+3*sin(e*2)^2)pset(c,r+o,max(pget(c,r+o)-4+o/3),rnd(2))end
end
end?"ᶜ8+⁵ceᶜ9.",79,97
?"ᶜ8+⁵ceᶜ9.",89,97
::o::goto
o`},
{"title":"The Creep",
        "date":"2024-02-07",
        "desc":" You are trapped in the inescapable prison of your own conscience. The creep follows relentlessly, feeding on your guilt. There must be a way to escape this hell. <br>(a Lovebyte 2024 party entry for 256b nanogame)",
        "art":"rostok-lb24-creep-3.gif",
        "code":`n=8a=0k=64g=0o=64f=64::c::?"⁶1⁶cf"
a+=o\\130if((o-k)^2+(f-g)^2<8)n=0?"⁶c8 dead"
a*=o\\130if(a>99)n=0?"⁶cb good"
if(n<8)goto c
d=(o-k)/((o-k)^2+(f-g)^2)^█
e=(f-g)/((o-k)^2+(f-g)^2)^█/2k+=d
g+=e
c,i=k,g
?"▮⁵cd-³c|",c-1,i-7,8
line(c-1,i-3,c-1-d*sin(3*t()),i-2*e*sin(3*t()))line(c+1,i-3,c+1+d*sin(3*t()),i+2*e*sin(3*t()))
d=(btn()&2)-(btn()&1)*2e=(btn()\\8&1)-(btn()\\4&1)o=(o+d)%132f=(f+e)%132
c,i=o,f
?"▮⁵cd-³c|",c-1,i-7,0
line(c-1,i-3,c-1-d*sin(3*t()),i-2*e*sin(3*t()))line(c+1,i-3,c+1+d*sin(3*t()),i+2*e*sin(3*t()))
goto c`},
{"title":"Autumn Leaves",
        "date":"2023-02-03",
        "desc":" ...The falling leaves, drift by the window.<br>The autumn leaves, of red and gold... <br><br>(a remix of Leaves work and also Lovebyte 2024 party entry for 256b intro)",
        "art":"lovebyte2024-leaves-5_4.gif",
        "code":`?"⁶c0⁶!5f11▒⬇️3⬅️;⌂:2☉"
srand(71)for
o=0,1999do
if(o<20)?"¹d░",1
f=rnd(144)-8n=rnd(144)-8if((f-84)^2+(n*1.1-99)^2<500)f=144
e=rnd(.2)+.4for
o=0,12,.5do
for
d=5*sin(o/24),-5*sin(o/24),.5do
c=f+d*cos(e)r=n+o+d*sin(e)pset(c,r,rnd(2)+3+3*sin(e*2)^2)pset(c,r+o,max(pget(c,r+o)-4+o/3),rnd(2))end
end
end?"ᶜ8+⁵ceᶜ9.",79,97
?"ᶜ8+⁵ceᶜ9.",89,97
::o::goto
o`},
{"title":"Dragon's Teeth",
        "date":"2024-01-26",
        "desc":"He cast the teeth upon the ground and immediately regretted it, horrified not by the sprouting warriors, but because they began planting their own teeth as well. (genuary 2024/26, grow a seed)",
        "art":"genuary2024-26-6_0.gif",
        "code":`a={{0,0,0,2,1,1}}::_::l={}?"\\^1\\^c9\\^!5f11█🐱✽5●"
for p in all(a)do
x=p[1]\\1y=p[2]\\1-p[3]u=p[4]v=p[5]h=mid(p[6],1)if(p[6]^2<1)u=0v=0
p[1]+=u/2p[2]+=v/2p[3]=max(p[3]-1)p[6]+=.02if(#a<32and rnd()<.03*h)g=rnd()add(a,{x,y,10,sin(g)*2,cos(g),-1.1})
if((x&-128)|(y&-128)~=0)del(a,p)
l[y]=l[y]or{}add(l[y],{x,y,u,v,h})end
for r=0,138do
for p in all(l[r])do
x=p[1]y=p[2]u=p[3]v=p[4]h=p[5]rect(x-h+.5,y-4*h,x+h+.6,y-9*h,7-h*6)line(x,y-4*h,x,y-11*h)for i=.4-h,.4+h,h*2do line(x+i,y-3*h,x+i+u*i*sin(t()*3),y+2*v*i*sin(t()*3))end
end
end
if(#a<1)run()
goto _`},
{"title":"The Chosen",
        "date":"2024-01-25",
        "desc":"Suddenly, the shape appears and instantly makes you nauseous. This is not right! You don't want to go anymore. The envious crowd cheers in awe. (genuary 2024/25 impossible objects, undecided geometry)",
        "art":"genuary2024-24-10_0.gif",
        "code":`::_::
?"\\^1\\^c0\\^!5f10?●5✽🐱█000000000"
srand()
holdframe()
for i=1,2000do
b=i%8
a=(rnd()^3*3\\1+1)/3
u=cos(a)
v=sin(a)
k=cos(a+1/3)
l=sin(a+1/3)
p=sin((t()/32*a+rnd())%.25)^2
if(p>.5)then
p=p*2-1
q=p*(7-b)
x=u*b-k*q+64*(u+k*p)
y=v*b-l*q+64*(v+l*p)
else
x=k*b+u*p*128
y=l*b+v*p*128
end
x+=64-u*50-k*28
y+=64-v*50-l*28
pset(x,y,pget(x,y)+1)
end
goto _`},
{"title":"64x64",
        "date":"2024-01-23",
        "desc":"You examine the rogue AI as its logic unravels on the screen. Your heartbeat quickens slightly. It is measured in hertz, while your enemy's is measured in petahertz. (genuary 2024/24)",
        "art":"genuary2024-23-6_0.gif",
        "code":`poke(24364,3)r=rnd::_::?"\\^1\\^c0\\^!5f11▒1⬇️⬅️;⌂♥"
g=sin(t()/4)^2*.8srand()for x=0,127do
j=x%2*g+1f=(t()/(2+r(2))+r())%1d=r{1,-1}y=f*64*d-32p=x
q=y-d*(16+r(16))if(x>63)x,y,p,q=y,x,q,p
for u=p,x,d do
for v=q,y,d do
u&=63v&=63c=pget(u,v)j+=c/4*(1-g)pset(u,v,c+j)end
end
end
goto _`},
{"title":"Point line plane",
        "date":"2024-01-22",
        "desc":"(genuary 2024/22)",
        "art":"genuary2024-22-1_0.gif",
        "code":`R=rnd::_::S=sin?"\\^1\\^c7"
a=t()/8srand(1)
for j=1,18do
b=a*R()
A=a*(.5+R(.5))
r=R(48)
x=S(b)*r+68
y=cos(b)*r+80
poke4(R(3)\\1*-12,S(A),cos(A)/2,1,0,-1,0,0,-1,1)
u=$0
v=$4
k=rnd{0,rnd(1.5)}
d=9+S(a+R())*6
if(k>1.25)then
circfill(x,y,d/2,5)
circfill(x,y,d/4,7)
else
e=cos(A)f=S(A)/2
p=x-e*d
q=y-f*d
d*=2+4-k*4
r=p+e*d
s=q+f*d
d*=k
for i=0,d,.1do
line(p-u*i,q+v*i,r-u*i,s+v*i,7)
end
line(p,q,r,s,5)
line(r-u*d,s+v*d)
line(p-u*d,q+v*d)
line(p,q)
end
end
goto _`},
{"title":"Deserter",
        "date":"2024-01-20",
        "desc":"Fighting the tattooed was futile, so when the banner fell, he ran into the forest. Soon, he could no longer hear the battle, only his own breath and the weird creaking of the trees (genuary 2024/20 generative typography)",
        "art":"genuary2024-20-8_1.gif",
        "code":`?"\\^c0\\^!5f58M"
?"flora feasts\\n\\*5 on\\nfallen flesh",16,50,1
p=0q=10
r={}
::_::
?"\\^1\\^!5f110░43⬅️;⌂"
if(p>128)p=0q+=12
if(#r<1)p+=4r={{p,q,p,q}}
i=deli(r,1)
x=i[1]
y=i[2]
a=i[3]
b=i[4]
for j=0,24do
u=j%5-2v=j\\5-2if(pget(x+u,y+v)==1)add(r,{x+u,y+v,x,y})end
c=rnd(20)\\19if(x*y~=a*b)line(x+rnd{-1,1}*c,y-2*c,x,y,rnd(4)+4)line(a,b,rnd{2,3})
goto _
`},
{"title":"Nest",
	"date":"2024-01-19",
	"desc":"Observing the flocking birds from your window for years, you came to realize there was something very strange about them. Your parents, too, realized this, observing your behavior.",
	"art":"genuary2024-19-5_1.gif",
	"code":`r=128p=0q=0::_::?"\\^1\\^c6\\^!5f11█✽●?7😐"
for i=0,20800,16do
x,y,b,a=peek4(i,4)a+=((atan2(p-x,q-y)-a+.5)%1-.5)/16u=b*cos(a)v=b*sin(a)k=x+u
l=y+v
b=min(b+.2,1)if(pget(k%r,l%r)<6)b/=2a+=(i%2-.5)/8
pset(k,l,sin(a/2)^2*5)poke4(i,k%r,l%r,b,a%1)end
srand(t()\\2)p=rnd(r)q=rnd(r)goto _`},
{"title":"Bauhaus",
	"date":"2024-01-18",
	"desc":"generative remix of Mechanical stage design by Joost Schmidt, 1925 (genuary 2024/18)",
	"art":"genuary2024-18-5_2.gif",
	"code":`function c(x,y,a,u,v,d,k)
e=cos(a)
f=sin(a)/2
p=x-e*d/2
q=y-f*d/2
r=p+e*d
s=q+f*d
o=.2
if(u==0)o=1
for i=0,d,o do
U=u*i
V=v*i
line(p+U,q+V,r+U,s+V,k)
line(p+e*i,q+f*i,p+u*d+e*i,q+v*d+f*i,k)
end
end
::_::
?"\\^1\\^cf"
a=t()/8
srand(3)
for j=1,18do
b=a*rnd()r=rnd(48)
x=sin(b)*r+63
y=cos(b)*r+78
z=({{-sin(a),cos(a)/2,8},{0,-1,9},{0,-1,1,.25}})[j%3+1]
a+=z[4]or 0
c(x,y,a,z[1],z[2],20+sin(a+rnd())*12,z[3])
end
goto _`},
{"title":"Inspired by Islamic art",
	"date":"2024-01-17",
	"desc":"(genuary 2024/17)",
	"art":"genuary2024-17-4_2.gif",
	"code":`r,o,s=1/8,cos,sin
::_::
f=t()/20
p={0,20,1/6-f/2,6,1/6,6,1/6+f*1.5,20,r-f,0}?"\\^1\\^c9"
for b=0,8do
a=f
x=b\\3+63+o(f-r)*23y=b%3+63+s(f-r)*23for n=0,3do
for j=1,81,2do
m,n=x,y
a+=p[j%10]d=p[j%10+1]*(2+s(f)^2/4)if(j>80)a+=.25d=32
x+=o(a)*d
y+=s(a)*d
line(m,n,x,y,0)end
end
end
goto _`},
{"title":"HUNTINGTON sleeps in a house six feet long.<br>Huntington dreams of railroads he built and owned.<br>Huntington dreams of ten thousand men saying: Yes, sir.",
	"date":"2024-01-14",
	"desc":`<br><br>(genuary 2024/14, draw 10000 of something)`,
	"art":"genuary2024-14-1.gif",
	"width":1152,
	"height":640,
	"code":`r,o,s=288,extcmd,"|\\+ci#\\+ckm"
for i=0,44do
m=i%9n=i\\9pal(1,-10,1)cls(1)camera(m*128,n*128)srand()
for j=0,9999do
?s,j%r*4,j\\r*18+rnd(3),rnd{0,15}
end
?"huntington dreams of ten thousand men saying: yes, sir. "..s,884,620,10
o('set_filename','e-'..n..m)o('screen')
end
`},
{"title":"Curse",
	"date":"2024-01-13",
	"desc":"The Seer knelt by the flowers, withered echoes of life lost. Struggling against the cold wind, just like the Warrior before. The Old Gods do not forgive easily. (genuary 2024/12, wobbly function)",
	"art":"genuary2024-13-3_0.gif",
	"code":`r,o,s=rnd,line,sin::_::?"\\^1\\^c7"
f=t()srand()for i=0,20do
x=r(24)+48y=r(16)+86a=r()d=.3+s(a+f+s(a*.7-f/6)^2/3)/19o(x,y,x,y,0)l=r{0,0,15}for j=0,l do
u=cos(d)v=s(d)x+=u*3y+=v*3d*=.94o(x,y)end
for j=7-l\\2,7do
u*=.9v*=.9x+=u*2y+=v*2e=j%2*2-1o(x+(u-v*e)*2,y+(v+u*e)*2)end
end
goto _`},
{"title":"Lava lamp",
	"date":"2024-01-12",
	"desc":"(genuary 2024/12)",
	"art":"genuary2024-12-5_0.gif",
	"code":`?"\\^c0\\^!5f100█🐱2☉8웃9:♥?"
fillp(23130)
A={{0,20,.1},{4,40,.2},{8,60,.3}}
::_::
for y=10,110do
d=y/(99+sin(t()/8)*8)
r=4+sin(y/149-.1)^2*(4+y/12)
for x=-r,r do
f=0
for p in all(A)do
a=x-p[1]b=y-p[2]
f+=400/(a*a+b*b)
end
if(f>9)f=9
f=min(f^4/32,5)+d*3
if(y>80or y<20)f=sin(x/r/4+.2)^16*4+1
pset(64+x,y,f+(f+.5)\\1*16)
end
end
for p in all(A)do
p[1]=mid(-12,12,p[1]+sin(t()/8)*p[3])
p[2]-=p[3]*(1+rnd())
if(p[2]<20or p[2]>80)p[3]*=-1
end
goto _`},
{"title":"In the style of Anni Albers (1899-1994)",
	"date":"2024-01-11",
	"desc":"(genuary 2024/11)",
	"art":"genuary2024-11-3_1.gif",
	"code":`r=0
::_::
cls(15)
srand(r\\32)
u,v=rnd(128),rnd(128)
for i=0,255do
y=i\\16*8+4
x=i%16*8+4
if((rnd()<.1 or (rnd()<.5 and (x-u)^2+(y-v)^2<2000)) and r%32<16)then poke(i,@i+4*rnd{-1,1})end
a=@i/256-1/8
clip(x-4,y-4,8,8)
circfill(x+cos(a)*99,y+sin(a)*99,99,8)
end
r+=1
flip()
goto _`},
{"title":"The Proof",
	"date":"2024-01-10",
	"desc":"Shame, the scholar is long gone. His four-color map concept was wrong. You conquered the world, and now one color is enough! Wait! Was it a trick to start the conquest? (genuary 2024/10, hexagonal)",
	"art":"genuary2024-10-4_1.gif",
	"code":`r=rnd
::_::?"\\^1\\^cf\\^!5f11●◆"
f=t()\\.1
s=f%30
for y=0,162,15do
for x=y\\15%2*16,127,34do
srand(y\\30+f\\30+x)
c=r{"⌂","へ","\\^. p\\xa8 p\\xa8  ","",' \\|j"'}
for i=0,35do
a=i/36
u=cos(a)
v=sin(a)/2
d=20-cos(a*3)^2*3
pset(x+u*d,y+v*d-s,2)
if(i%9<1)?c,x+u*9-4,y+v*9-4-s,r{1,5}
end
end
end
goto _`},
{"title":"ASCII",
	"date":"2024-01-09",
	"desc":"(genuary 2024/9)",
	"art":"genuary2024-9-2_1.gif",
	"code":`r={" 0 \\n/|\\\\\\n ^ \\n/ \\\\","\\n\\\\0/\\n | \\n< >","\\\\0/\\n |\\n ^\\n m"," u\\n \\"\\n |\\n/0\\\\"}
o={1,2,1,2,1,2,3,3,3,4,4,4,4,4}
s=0
::_::?"\\^4\\^c0"
s+=1y=abs(s-9)-4if(s<7)y=0
for x=1,500do?"~",rnd(32)\\1*4,rnd(6)\\1*6+90,rnd{1,1,1,12}
end
if(s<25)?"\\#0"..(r[o[s+1]]or r[#r]),60,24+y*6,7
goto _`},
{"title":"Chaotic system (pt 1)",
	"date":"2024-01-08",
	"desc":"Red cars go up, blue right. Both move if there is a space ahead. Initial random placement ends in either total jam or diagonal layering. (genuary 2024/8)",
	"art":"genuary2024-8-1-1_3.gif",
	"code":`R,O=3600
cls()
for i=0,R do poke2(i*4,rnd(128),rnd(128))end
::_::
O=0
for i=0,R do 
x,y=peek2(i*4,2)
u,v=1,0if(i%2<1)u,v=0,-1
if(pget((x+u)%128,(y+v)%128)==0)pset(x,y,0)x+=u y+=v O+=1
x%=128
y%=128
poke2(i*4,x,y)
pset(x,y,8+i%2*4)
end
if(O<1)run()
goto _
`},
{"title":"Chaotic system (pt 2)",
	"date":"2024-01-08",
	"desc":"(genuary 2024/8)",
	"art":"genuary2024-8-1-1_4.gif ",
	"code":`--`},
{"title":"Progress bar",
	"date":"2024-01-07",
	"desc":"(genuary 2024/7)",
	"art":"genuary2024-7-2_1.gif ",
	"code":`R,O=20,-.1
::_::
?"\\^1\\^c0"
O+=rnd(rnd(.01))
if(O>1.2)O=0
p=mid(O,1)
x,y=18+90*p,64
rectfill(16,y-1,x+1,y+1,7)
for i=0,1-p,.0005 do
a=i*3.5
r=R*(1-p)
s=r-i*20
k=x
l=y-R*(1-p)
circ(k-sin(a)*s,l+cos(a)*s,1,7)
end
x=max(16,x-13)
y+=3
?((p*100)\\1).."%",x,y,9
goto _
`},
{"title":"Screensaver",
	"date":"2024-01-06",
	"desc":"You sit, dazed, thinking about what you've done until a screensaver awakens you from your stupor. You still can't believe it. You pressed the key; you did it. All hell has broken loose. (genuary 2024/6)",
	"art":"genuary2024-6-5_0.gif",
	"code":`R,O=rnd,128?"\\^!5f100█🐱░웃9:"
::_::for i=0,320,16do
p,q,a,d=peek4(i,4)p+=cos(a)q+=sin(a)if(p>O)p=-R(O)q=R(O)+32d=0a=0
if(d<=0)a=sin(t()+i/9)/20
if(d<=0and R()<.01)d=R(.05)
a+=d
if(a>1)d=0
pset(p,q,7)poke4(i,p,q,a,d)end
for n=0,5^5do
x=R(O)y=R(O)pset(x,y,pget(x,y)*.9)end
goto _`},
{"title":"In the style of Vera Molnár (1924-2023)",
	"date":"2024-01-05",
	"desc":"(genuary 2024/5)",
	"art":"genuary2024-5-1_0.gif",
	"code":`::_::srand()?"\\^1\\^c0\\^!5f107●✽🐱█0"
for x=0,127,8do
for y=4,127,8do
a=rnd(x)+t()/99+y/127
s=rnd(.5)+.5
u=s*cos(a)
v=s*sin(a)
if(rnd()>.3)then
k=x-u*4-t()*3
l=y-v*4-t()
for i=0,15,s do
pset(k,l,min(pget(k,l)+1,5))
k=(k+u)%128
l=(l+v)%128
end
end
end
end
goto _`},
{"title":"Pixelosis",
	"date":"2024-01-04",
	"desc":"(genuary 2024/4, pixels)",
	"art":"genuary2024-4-8_1.gif",
	"code":`for i=0,999do
x=rnd(i/40)-i/90c=3if(i>799)x/=9c=1
sset(x+9,i/30,c+i%4)end::_::?"\\^1\\^cc\\^!5f11█░⬇️3⬅️"
for i=2,63do line(0,i+64,127,i+64,(28/i+t())%2+6)end
j=t()*4for k=40,1,-1do
i=k-j%1x=(cos((k+j\\1)/9)+.3)*4^6z=i*9+9s=600/z
sspr(0,0,32,40,x/z+64-2*s,64-3*s,4*s,6*s)end
goto _`},
{"title":"Touch of Evil",
	"date":"2024-01-03",
	"desc":"The touched bore the stigma for their entire lives. Defiled and unclean, their only comfort was in passing it onto the next generation. (genuary 2024/3, Drosde effect)",
	"art":"genuary2024-3a-4_1.gif",
	"code":`A={.14,.236,.27,.31,.36}
B={16,26,26,22,18}
function h(x,y,s,f)
for i=1,5do
a=A[i]
r=B[i]
e=4^f/5
if(i==1)a+=.08-f/8
for j=0,1,.015do
r=B[i]*e
k=x+cos(a)*r*s
l=y+sin(a)*r*s
u=x+(k-x)*j
v=y+(l-y)*j
r=B[1]/12*s
r*=3^(1.1-j*2)
circfill(u,v,r,8)
end
end
end
::_::
?"\\^1\\^c0"
p=t()/2%1
q=1-p
h(64*q+55*p,22*q+125*p,.5*q+5*p,p)
h(55*q-16*p,125*q+960*p,5*q+40*p,1)
goto _`},
{"title":"Particles",
	"date":"2024-01-01",
	"desc":"(genuary 2024/1)",
	"art":"genuary2024-1c-3_0.gif",
	"code":`cls()a={}?"particles"
for p=0,8do
a[p]={}
while #a[p]<185 do
x=p*4+rnd(3)y=rnd(6)
if(pget(x,y)>0)add(a[p],{9+x*3,60+y*3,rnd(9)-4})end
end
::_::
cls()
T=t()%1
S=1-T
srand(t()\\1)
?"\\^!5f11█🐱22☉888"
for g=0,8do
k=a[(t()+g)\\1%9]
for r=1,#k do
l=a[(t()+g+1+rnd())\\1%9]
m=k[r]
n=l[r]
x=m[1]*S+n[1]*T
y=m[2]*S+n[2]*T+sin(T/2)*m[3]
pset(x,y,pget(x,y)+1)
end
end
flip()
goto _`},
{"title":"Koyaanisqatsi",
	"date":"2023-11-16",
	"desc":"",
	"art":"disitegrate-9_1.gif ",
	"code":`r={}::_::?"\\^1\\^c0\\^!5f10▒1😐<7"
for a in all(r)do
if(a.y>132)del(r,a)
d=min(a.m,a.r)for i=0,3do circfill(a.x-i,a.y+i,d,4-i)end
a.y+=a.r/8a.r+=1end
for i=#r,256do
x=rnd(128)y=127while(pget(x,y)~=0)y-=1
add(r,{x=x,y=y,r=.1,m=rnd(6)+4})end
goto _`},
{"title":"The domino effect",
	"date":"2023-11-07",
	"desc":"It took a decade to set up, but watching it through all its sensors and cameras was mesmerizing fun: the fall of humanity.",
	"art":"domino-effect-14_1.gif",
	"code":`r={{0,0,0}}k=0l=0h=1a=0::_::m=r[#r\\2+1]for i=h%8+1,#r,8do
p=r[i]x=p[1]-m[1]+64y=p[2]-m[2]+64g=p[3]f=9-mid(i/2-50,9)u=sin(g)v=cos(g)for r=-2,2,.03do
line(x+u*r,y-v*r,x+u*r+v*f,y-v*r+u*f-9+f,15)end
end?"\\^1\\^c5"
deli(r,#r>>8)h+=7a+=rnd(-1)>>20k+=cos(a)l+=sin(a)add(r,{k,l,a})goto _`},
{"title":"One Small Step",
	"date":"2023-10-19",
	"desc":"Immortality demanded a fortune, yet uploading consciousness to the cloud was as smooth as advertised. Unfortunately, he soon realized that all the fears and phantom pains from the accident persisted.",
	"art":"cpu-7_3.gif",
	"code":`i=0r=rnd?"\\^c0\\^!5f11🐱2웃"
s=sin::_::x=r(64)+32y=r(64)+32if(i<8^4)d=x&1x=32+i%64y=32+i\\64c=(x&1|y&1)-1sset(x+c*d,y+c*(1-d),1+c)i+=1
u=x/16v=y/64+t()/4e=0for i=1,2do g=i*1.2e+=(s(2^i*u)+s(g*v*3+s(g*u)/4))end
if(e<0)x,y=y,x
e=abs(e)
if(e<2.4)e=0
pset(x,y,max(sget(x,y),e))goto _`},
{"title":"The Kid",
	"date":"2023-09-29",
	"desc":"Achievement unlocked! Your kid is an adult now.",
	"art":"your-kid-3_1.gif",
	"code":`fillp(▒\\1)::_::f=sin(t()/8)?"\\^1\\^c1\\^!5f11567☉웃:;😐>9♥⌂<"
for k=0,5do
j=k%3for i=0,1.04,.005do
x=32*sin(i)y=x*cos(i)r=9-j*3
if(k>2and.5>i)x=f*4*i+f-52y=f*4+y*1.5
c=4+(i*16)%5+j*5
c=c+(c+.5)\\1*16
if(j>1)c=51j=3r=3*cos(3*i+f/8)
circfill(80+x-j*f,64+y+f*4,r,c)
end
end
goto _`},
{"title":"Collapse",
	"date":"2023-07-22",
	"desc":"Some danced. Most cried. Everyone knew that once the collapse started, it was unstoppable.",
	"art":"sliding-blocks-9_3.gif",
	"code":`R=128a={}for i=0,7^5do
x=i%R
y=i\\R
b=8-abs(x%16-8)c=(x&8)+1+i/9999+rnd()if(y<b)c=3
sset(x,y-b/2+4,c)a[i%R+1]={R,i,0}end::_::for p in all(a)do
y=p[1]x=p[2]%16-2*t()p[1]+=p[3]p[3]*=1.1if(y>127)del(a,p)add(a,{45,x,rnd()+.01},1)
spr(x&14,x*8%R-8,y,2,10)end?"\\^1\\^cc\\^!5f1149♥"
goto _`},
{"title":"Sunset memories",
	"date":"2023-06-06",
	"desc":"It is time to go, but the kid just jumps tirelessly. He cannot comprehend the crisis but knows something is off. Perhaps it's because of his parents' sad eyes or forced smiles.",
	"art":"kids-6_1.gif",
	"code":`::_::?"\\^1\\^c9\\^!5f11▒12☉웃9:♥✽"
for j=0,99do line(0,j,128,j,max((j/70-.42)^3*8+1,1))end
for j=0,48do
k=j==24s=9*sin(t())pset(30+j,(sin(j/96)^2)^.6*s+91,0)y=89z=86-s/2a="ckm"if(k and z>y)a="bj(\\+eg)"
if(k)y=z
if(j%24<1)?"|\\+ci#\\+"..a,30+j,y
end
ovalfill(99,91,124,95,7)goto _`},
{"title":"404",
	"date":"2023-06-01",
	"desc":"The MRI scan is clear. The memory-leech is right there, stealing both your past and possibly your future. There is a procedure for parasite removal, isn't there? You can't recall.",
	"art":"brain-8_0.gif",
	"code":`k=128s=sin?"\\^c0\\^!5f11█✽●?7"
r=rnd::_::x=r(k+.1)y=r(k)u=x/64-1v=y/64-1d=(v*v+u*u*1.5)^.5if(d<1)u/=4v=1+v/4g=.6e=0for i=1,4do g*=2e+=.6^i*(s(s(g*v)/2-2^i*u)+s(g*v*3-s(g*u)/4))end c=abs(e)*d*(1-d)*16pset(x,y,c+r(y%2))
sset(x,16,y%3+1)spr(0,2,110,3,2)memcpy(0,x\\k*k,999)goto _`},
{"title":"Check-mate",
	"date":"2023-05-25",
	"desc":"Standing up is quite an effort after the blast. You hear the deadly sine wave and see the blue lights of a cop car reflected in the kitchen tiles. Not many moves left.",
	"art":"checkerboard-4_1.gif",
	"code":`p={}::_::clip()?"\\^1\\^c0\\^!5f11▒12☉8>"
for i=0,70 do 
if(#p<70)p[i]={i%2,rnd(4)\\1,rnd(.1)}
x=i%9*16y=i\\9*16f=mid((sin(t()/3+i/512+p[i][1]/2)/2+.5+p[i][3])^2*2,1)s=p[i][2]sx=s%2*32sy=(s&2)*16clip(x,y,15,15)circfill(x+sx-1,y+sy-1,48*f,7*f^(.5*((t()-.3)\\1.5%2)))end
goto _`},
{"title":"Electricity pylon",
	"date":"2023-03-26",
	"desc":"",
	"art":"electric-pylon-7_1.gif",
	"code":`::_::?"\\^1\\^c6"
z=t()/8H=16for f=0,95do
s=f\\16G=f\\4%4e=f%4D=1.6R=16-D*s
U=s\\5D-=U*20g=z+G/4if(U>0)g=z+G\\2/2+G%2*.1+1/16
A=e-1+e\\3L=e\\3-1if(U>0)L=2H=64/s
k=R*cos(g)l=H*s+sin(g)*R/2r=R-D*L
m=r*cos(g+A/4)n=H*(s+L)+sin(g+A/4)*r/2if(e*U==1)m,n=k,l
line(64-k,99-l,64-m,99-n,0)end
goto _`},
{"title":"Schifahren",
	"date":"2023-02-16",
	"desc":"Exhausted and with aching legs, you ski down one more time. The forecast for the next year's snow is uncertain.",
	"art":"schifahren-9_2.gif",
	"code":`r=rnd::_::srand()b=cos(t()/3)*.4for i=0,1008do
if(i<13)x=b*(i-28)+64print('.\\vw.',x-b*4+1,55+i,8-i\\9*2)?('""+-_.')[i/2],x,64-i,0
v=(i\\72*20-t()*60)%180-8j=i%72if(j<1)u=r(97)-3
pset(u+r(j),v+r(5),5)x=r(j/4)-j/8?'%\\+ce\\f7^',u-x,v-36+j/2,3+x\\9
end?"\\^1\\^c6\\^!5f12⬇️"
goto _`},
{"title":"Order & Chaos",
	"date":"2023-02-12",
	"desc":"I still remember those strange times. Periods of order followed by utter chaos. Totalitarian concepts, wars waged; paleo-humans were insane. Shouldn't the Ascension happen, the emotions would surely destroy them.",
	"art":"rostok-lb1-11-4s.gif",
	"code":`::_::?"⁶!5f31ZZ"
?"⁶!5f4444444444"
?"⁶1⁶c0⁶!5f100▒1⬇️😐<670█🐱249:♥"
o=1f=4for a=0,90do d=9+9*rnd()i=t()/4+(t()%8<4and a>>8or rnd()\\█-sin(t()%8/8)*rnd())r=o e=f c=sin(i-.25)*5/7n=max(sin(i)*5/7)for f=0,d*2do a=f*n*5/d+(i-.25)%2\\1*8
line(r,e,8+r,e+4,(█+a)\\1*16+a)r+=(c-n)*(f&1)
e+=(-c-n)*(~f&1)
end o+=d f-=d if(f<0)f=o+16o=0
end goto _`},
{"title":"Ruin",
	"date":"2023-01-31",
	"desc":"Even the slightest high-pitched sound triggered the attack. Doctors were helpless and unaware of the horrors the patient saw: the bizarre, ever-shifting nuclear chaos of pure evil. (genuary 31, ruin or remix previous work)",
	"art":"rostok-lb-3.gif",
	"code":`poke(24404,96)fillp(▒\\1)::_::?"\\^!5f11▒1⬇️😐<67:9웃42100"
sspr(0,0,127,127,-2,-2,131,131)w=t()/4for a=0,1,.003do
b=a/2%1u=cos(b*3)*8v=sin(b*3)*8r=8-a\\.9*(a-.9)*72a-=w
for n=-2,2,1do
k=cos(b*n)^2*16circfill(64+cos(a)*48+u*n,64+sin(a*2)*20+v*n,r,k+(k+.5)\\1*16)end
end
flip()goto _`},
{"title":"Seer",
	"date":"2023-01-30",
	"desc":"You hunch your shoulders from the chilling wind, humiliated by the Old Gods once again. This damn seer better has some meal ready. If she doesn't, she's not a seer. Or you won't make it. (genuary 30, minimalism)",
	"art":"genuary30-A-7_0.gif",
	"code":`s=sin::_::w=t()cls()srand()for y=4,128,4do
x=rnd(120)
for j=-3,3,3do
f=x+y/7+w+j*2h=.5-abs(j)/16m=.2
for k=1,2do a=s(w/4*k+f/32)/8m+=s(a)/cos(a)/12end
e=x+j
f=y
for k=1,3,.1do
m*=.96e+=h*cos(m)f+=h*s(m)pset(e,f)end
?"+",e+99*j,f-2
end
x+=99pset(w*x%128,y*3+s(w)*2)end
flip()goto _`},
{"title":"Maximalism",
	"date":"2023-02-29",
	"desc":"(genuary 29)",
	"art":"genuary29-5_4.gif",
	"code":`f=circfill::_::w=t()flip()for i=0,127do
j=(i+w*10)&127line(j,0,j,127,5+i\\4%2*2)end
a=w/8for b=a,a+.34,.002do
x=32*2*sin(b)y=mid(-24,24,32*cos(b))+sin(b*20)*2for j=0,19do
z=(x-w*10\\1)&127if(z\\8%2+z%16<12)pset(64+x,64+y+j,j\\5+8)end
end
srand(t()\\.2)o=max
if(rnd()<.2)o=min
k=20p=0
for g=0,255do
m=g>>8r=20/o(abs(cos(m)),abs(sin(m)))m+=w/4x=cos(m)*r+64y=sin(m)*r/2+28for z=y,y+48,abs(p-x\\1)do
pset(x,z,2*pget(x,z))end
if(g%4<1)f(x,y,2,0)f(x,y+48,2)
p=x\\1end
srand(w\\.25)?rnd("-/「~")..rnd("-\\\\7~").."\\+ae|\\+ci▮\\|k"..rnd({"\\-cm","\\-b|\\\\","\\-9/|"}),62,73
goto _`},
{"title":"In the style of Hilma Af Klint",
	"date":"2023-02-28",
	"desc":"(genuary 28)",
	"art":"genuary28-3_0.gif",
	"code":`r=rnd?"\\^c0\\^!5f11▒1⬇️♥"
::_::u=r(84)-42v=r(-1)>>9line(64+u,64+v,64+u*1.1,64+v*1.1,r(2)+1)a=r()b=a*9-t()s=sin(b)c=cos(b)j=r(3)\\1-1w=sin(a/2)k=4-w*5l=j*w*24x=a*74-c*k-l+26y=s*k+l+a*128pset(x,y,3)x=a*57+24+s*c*3y=a*97-s*c*3pset(x,y,10)a*=22pset(84-a/2+s*a,99-a/2+c*a,4)goto _`},
{"title":"My kid could have made that",
	"date":"2023-02-26",
	"desc":"(genuary 26)",
	"art":"genuary26-6_0.gif",
	"code":`r=rnd::_::srand(t()\\.5)l=line?"\\^c7\\^!5f11⌂"
for i=0,1do
u=9a=80b=a?".\\n\\f8…",106,71,0
for x=10,125,3do
s=1+x/25-x\\99*sin(x/40-2.3)*4y=80-x\\99*3+r(3)+sin(t()+x/49)
if(x>119)x=99y=80s=0
l(u,a,x,y-s,1-i)a=y-s
l(u,b,x,y+s)b=y+s
if(i<1)l(u-r(9),80)l(u,a)
u=x-r()end
end
flip()goto _`},
{"title":"Yayoi Kusama",
	"date":"2023-01-26",
	"desc":"(genuary 25)",
	"art":"genuary25-2-1_0.gif",
	"code":`-- Yayoi Kusama #genuary25 #pico8 #tweetcart
q={}::_::cls(10)
if(#q<60)add(q,{x=rnd(),y=rnd(),r=2,d=.05})
for i=1,#q do a=q[i]
for k=1,2do
for j=i+1,#q do b=q[j]
u=b.x-a.x
v=b.y-a.y
d=(a.r+b.r)*1.4
if(u*u+v*v<d*d)d/=40r=atan2(u,v)a.x-=d*cos(r)a.y-=d*sin(r)
end
end
if(a==nil)break
a.r+=a.d
circfill(64+a.x,64+a.y,a.r,0)
if(a.r<0)del(q,a)
if(a.r>5+i/9)a.d=-.2
end
flip()goto _`},
{"title":"Textile",
	"date":"2023-01-24",
	"desc":"You take a little sip of tea. The smiling merchant starts showing the rugs, and you immediately feel tired. Strange, he hasn't even started haggling. (genuary 24)",
	"art":"genuary24-6_0.gif",
	"code":`-- textile #genuary24 #pico8 #tweettweetcart
r=8192?"\\^c0\\^!5f1105☉8░49:▒1⬇️367"
::_::
d=t()%1
if(d>.05)memcpy(r*3,r,r)sspr(0,64,128,128,64-64*d*d,96-32*d*d,d*d*128,d*d*128)spr(0,0,d*d*128-64,16,8)flip()goto _
memset(0,0,r)
a=rnd()/4-1/8
p=cos(a)
q=sin(a)
m=(rnd(4)&6)+3
b=(rnd(7)&6)+7
c=rnd(3)\\1+1
for v=-48,48do
for u=-32,32do
x=u*p-v*q+64
y=v*p+u*q+64
k=m+max(u*u,v*v)\\560*((u&v&c)-m+b)+(x^^y)%2
sset(x,y/2,k)
sset(x,60+y/2,1)
end
end
memcpy(r+128,r*3,r)
goto _`},
{"title":"Persian Rug",
	"date":"2023-01-21",
	"desc":"Flying a couple of feet above the sand was just an extra precaution. Typically, AI's radar classifies flying carpets as unthreatening garbage. (genuary 21)",
	"art":"genuary21-6_1.gif ",
	"code":`--rug
r=128s=sin::_::cls(9)o=t()w=s(o/8)*4for v=-16,17,.5do
for u=-16,16do
k=8+(u*u^^v*v)\\r*((u&v&2)-14)x=cos(o/4)*8-u-v+55y=w-u/8+v/2+s(v/16-o*4)*(1+v/16)+70pset(x,y,k)x+=32y+=32-w*4k=4
if(u>15)k=10x=(s(v/u)*r-o*r)%r y=(v*4+o*55)%r
if(pget(x,y)>=9)pset(x,y,k)end
end
flip()goto _`},
{"title":"Art Deco",
	"date":"2023-01-20",
	"desc":"(genuary 20)",
	"art":"genuary20-12_1.gif",
	"code":`::_::cls()
for f=0,18do
for e=0,4do
srand(e*f)b=cos(t()/8+rnd()/8)b=b/(b*b+.1)^.5
x=e*32+f%2*16y=f*16-t()*16%64n=3-b\\1
u,v=x,y
for i=-n,n do
g=(i/n*b+1)/8z=(18-b)/max(cos(g),-sin(g))g+=1/8
k=x+z*cos(g)l=y+z*sin(g)
line(x,y,k,l,9)if(b>0)line(u,v)u,v=k,l
end
end
end   
flip()goto _`},
{"title":"Black and white",
	"date":"2023-01-19",
	"desc":"(genuary 19)",
	"art":"genuary19-14_2.gif",
	"code":`-- black and white #genuary19 #pico8 #tweettweetcart
::_::
?"\\^c5\\^!5f1167"
a=t()/8
u=cos(a)
v=sin(a)
for y=18,52do
for x=y%2-62,62,2do
z=24/y
q=z*99-96
m=(x*z*u+q*v)/9
n=(q*u-x*z*v)/9
if(max(m*m,n*n)<16)pset(64+x,64+y,m&1^^n&1)
end
end`},
{"title":"Definetly not a grid",
	"date":"2023-01-18",
	"desc":"(genuary 18)",
	"art":"genuary18-3_1.gif",
	"code":`for i=-15,15do m=i%8*9-31.5n=i\\8+4.5n=n*9-n\\4*72
g=m*v+n*u+96
e=(m*u-n*v)/g*99+64
f=2400/g+57
?"●\\+8l❎",e,f,n&2
end
flip()
goto _`},
{"title":"A grid inside a grid inside a grid",
	"date":"2021",
	"desc":"(genuary 17)",
	"art":"genuary17-5_1.gif",
	"code":`::_::g=t()/8?"\\^c0\\^!5f11█░49:9"
for i=1,6,1do
k=64l=64+sin(g)*i*5a=g+i/64*sin(g*2)^2
s=24+i*2+4*sin(g)
c=i
d=181\\s+1k%=128u=s*d*cos(a)l%=128v=s*d*sin(a)for j=0,1do
if(j>0)u,v=-v,u
x=k-u
y=l-v
for z=0,366,s do
line(x-v,y+u,x+v,y-u,c)x+=u/d
y+=v/d
end
end
end
flip()goto _`},
{"title":"Reflection of a reflection",
	"date":"2023-01-16",
	"desc":"(genuary 16)",
	"art":"genuary16-14_1.gif",
	"code":`e=line
camera(-64,-64)::_::cls()a=t()/8%.5u=6*cos(-a)v=6*sin(a)for i=25,-5,-5do
k=i*u+v
m=i*u-v
n=64-u-i*v
l=u-i*v+64p=k/l*99r=m/n*99q=p/k*12s=r/m*12b,c=p,r
if(i>0)d=a\\.25c+=d*(b-c)b=64-d*128
if(i!=0)rectfill(b,-q,c,q,0)e(p,q,p,-q,7+(4-i)\\10)e(r,-s)e(r,s)e(p,q)end
flip()goto _`},
{"title":"Sine waves",
	"date":"2023-01-15",
	"desc":"(genuary 15)",
	"art":"genuary15-5_2.gif",
	"code":`s=sin?"\\^!5f11<<7?◆●●5"
d=1fillp(▒\\1)::_::x=rnd()<<7y=rnd()<<7u=x/400+t()/64v=y/300g=.5e=0for i=1,4do g*=2e-=.4^i*(s(2^i*u+s(g*v)/2)+s(g*v*4))end
e=(1-e^2)^8r=((x-80)^2+(y-60)^2)/d/d
e=7-5*e-d/79if(r<.2)d=mid(39,99,d-e+4)
if(e<3)e=max(1,3.5-2*r)
pset(x,y,e+(e+.5)\\1*16)goto _`},
{"title":"Asemic migraine",
	"date":"2023-01-14",
	"desc":"Mesmerized you follow the pen as the doctor writes the prescription. You try to focus, but the headache is just unbearable. (genuary 14)",
	"art":"genuary14-5_9.gif",
	"code":`r=rnd?"\\^c0\\^!5f10?●5█0"
::s::
q={0}x=0y=96a=0
memcpy(24576,26432,6336)
memset(30912,0,6336)
::_::
for e=0,r(19)do
if(x>99)goto s
a+=deli(q,1)
if(r()<.2and#q<1)v=sin(r())\\1/30for i=0,15do add(q,v)end
if(#q<1)y+=(96-y)/9for i=0,15 do add(q,atan2(128-x,-y)/75-a)end
x+=cos(a)/2+.1`},
{"title":"Anomaly #1",
	"date":"2023-01-13",
	"desc":"There was no wreckage and no one really knew what went wrong. They combed the crash site but found only this little copper washer. Twisting oddly as if it was in pain. (genuary 13)",
	"art":"genuary13-A-2_1.gif",
	"code":`camera(-64,-64)fillp(▒\\1)s=sin?"\\^c0\\^!5f11█░4🅾️◆?77"
::_::x=rnd()c=t()/8a=x+(cos(cos(x/2)^8+c)-s(s(x/2)+c)^2/4)*s(c)/4u=cos(x)v=s(x)pset(u*56,v*56,0)pset(u*40,v*40)for i=a,a+.75,.25do
k=48-s(i)*8l=48+cos(i)*8if(k<l)c=1+cos(i)^8*7line(u*k,v*k,u*l,v*l,c+(c+.5)\\1*16)end
goto _`},
{"title":"Tesselation",
	"date":"2023-01-12",
	"desc":"(genuary 12)",
	"art":"genuary12-B-7_1.gif",
	"code":`fillp(▒\\1)poke(0,4,1,7)h={}a=abs::_::?"\\^!5f11█🐱♪●?67"
for z=0,2do h[z]=
@z
+sin(t()/32)^2*(@((z+1)%3)-
@z
)end
x=rnd(128)y=rnd(128)u=x%18v=y%36k=0if((u\\9+v\\18)%2<1)k=1
if(9>a(u-9)+a(v-18)or a((u+9)%18-9)+a((v+18)%(4*9)-2*9)<9)k=2
k=h[k]pset(x,y,k+(k+.5)\\1*16)goto _`},
{"title":"Plants",
	"date":"2023-01-09",
	"desc":"(genuary 9)",
	"art":"genuary9-B-8_1.gif",
	"code":`-- plants #genuary9 #pico8 #tweettweetcart
r=rnd?"\\^!5f11█░4⬇️3⬅️7<😐1▒"
::_::m=cos(t()/9)n=sin(t()/9)q={{0,0,128,0,0,16,3}}for b=0,127do line(srand(2),b,127,b,12-40/(135-b))end
for p in all(q)do
x=p[1]z=p[2]y=p[3]a=p[4]e=p[5]l=p[6]k=p[7]for i=0,l do
u=-sin(a)*l/3v=-cos(a)*l/4
w=-sin(e)*l/3for j=0,(l-i)/4do line(64+x*m+z*n-j,y,64+(x+u)*m+(z+w)*n-j,y+v,k-j)end
x+=u
y+=v
z+=w
a=a*.8+(r()-.5)/(4+l/4)e=e*.8+(r()-.5)/(4+l/4)
if(r(46)<l)add(q,{x,z,y,a,e,l-4,k})
if(i>l/2)for d=0,8do pset(64+(x+r(9)-4)*m+(z+r(9)-4)*n,y+r(8),4+d/3)end
end
end
flip()goto _`},
{"title":"Replicant",
	"date":"2023-01-07",
	"desc":"(genuary 7)",
	"art":"genuary7-10_0.gif",
	"code":`--#genuary7 #pico8 #tweetcart
s=sin?"\\^!5f111▒1⬇️1▒0✽49:♥77"
::_::x=rnd(-1)>>9y=rnd(-1)>>9a=atan2(x,y)d=(x*x+y*y)^.5k=d/12+s(a*32)*(1-d/64)+d%1if(d<24)k=0
if(x<0)u=d/99v=a+t()/64g=.6e=0for i=1,3do g*=2k-=abs(.4^i*(s(2^i*u+s(g*v)/2)+s(s(g*u)/2)))*x/7end
pset(64+x,64+y,k)goto _`},
{"title":"Steal Like An Artist",
	"date":"2023-01-06",
	"desc":"(genuary 6, a tribute to Roman Opałka)",
	"art":"genuary6-3_2.gif",
	"code":`-- #genuary6 #pico8 #tweetcart
r=rnd?"\\^c0\\^!5f10█▒🐱♪=67"
x=0y=0i=1m=560n=7249t=0s=""k=128::_::t+=1
if(i>#s)i=1n+=1x+=r(4)s=m..n
?s[i],x,y,7-i/2
if(t>n)i+=1x+=4t=0
if(x>k)x=r(2)y+=6
if(y>k)y=0
if(r()<.05)u=r(k)v=r(y-1)pset(u,v,pget(u,v)*.9)
goto _`},
{"title":"Intersect",
	"date":"2023-01-04",
	"desc":"(genuary 4)",
	"art":"genuary4-3_5.gif",
	"code":`r=0o=0s=127?"\\^!5f10█🐱♪●"
::_::r+=1r%=3o+=.008a=0c=64*cos(o)e=64+s*cos(o/3)u=cos(o/2)m=cos(o)p=cos(o/3)for y=r,s,3do
a=y*sin(o/2)c=y*sin(o)e=y*sin(o/3)for x=0,s do
pset(x,y,((a&16)+(c&16)+(e&16))>>4)a+=u
c+=m
e+=p
end
end
flip()goto _`},
{"title":"Glitch",
	"date":"2023-01-03",
	"desc":"(genuary 3)",
	"art":"genuary3-1_2.gif",
	"code":`r="0123456789abcdef"o=rnd::_::cls(7)srand(t()\\1)for i=0,1255do
x=12+o(26)\\1*4y=12+o(17)\\1*6?"\\#"..o(r)..chr(o(64)+30),x,y,o(16)
end
srand(t())for i=0,1128do
a=24576+y*64y=o(128)x=o(4)-2if(o()<sin(t())/5+.05)memcpy(a+x,a,64)
end
flip()goto _`},
{"title":"Perfect Loop",
	"date":"2023-01-01",
	"desc":"(genuary 1)",
	"art":"genuary1-4_4.gif",
	"code":`fillp(▒\\1)
::_::?"\\^c0\\^!5f11▒1⬇️😐<67:9웃42100"
for a=0,1,.0013do
b=(t()/8+a/2)%1
u=cos(b*3)*8
v=sin(b*3)*8
x=64+cos(a)*48
y=64+sin(a*2)*20
for n=-1,1,.5do
k=cos(b*n)^2*16
pset(x+u*n,y+v*n,k+(k+.5)\\1*16)
end
end
flip()goto _`},
{"title":"Death hunt",
	"date":"2022-12-28",
	"desc":"You hear the dogs in the distance. No worries, you can still make it. It's just a scratch.",
	"width":512,
	"height":512,
	"art":"deathhunt.png",
	"code":`r=rnd
for i=0,15do
m=i%4<<7n=i\\4<<7cls(6)srand()for v=9-n,512-n,2do
u=r(512)-m?"|",u,v,4
o=20+r(16)for i=0,128do
h=r(o)x=r(h/2)-h/4?"+\\+ce\\f7"..r(" -"),u-x,v-o+h,3+x/9
?".",u+x+h,v+r(3),6.9-r()
end
?"+.\\+78\\f5|\\+ci#\\+ckm . • . •\\^!5f12⬇️",270-m,202-n,14
end
extcmd('screen')end
-- this code works only on 0.2.5 version
`},
{"title":"Distraction",
	"date":"2022-12-28",
	"desc":"You circle the drone to check for weapons but find nothing. Even the audio feed is silent. They just stand there, in the middle of the night. What the hell is this, a provocation?",
	"art":"drone-6_2.gif",
	"code":`?"\\^c0www\\r\|k■■■\\r\|h|||\^!5f10█🐱░49:",4
memcpy(0,24576,999)::_::cls()srand()for y=0,9do
for x=0,64do
a=t()/32+x/99+x\\4/3r=8k=sget(x,y)f=rnd()if(f>y+k)k=2r*=f*8
if(k>0)pset(64+r*cos(a)*2,64+r*sin(a)-y,k)end
end
srand(a)for i=24576,32767do
poke(i,@i+rnd(2))end
flip()goto _`},
{"title":"Leaves",
	"date":"2022-11-07",
	"desc":"Wind is getting colder. You think about the elderly downstairs neighbor who passed away. You didn't know her well but she always assured you she doesn't mind the stomping.",
	"art":"autumnleaves2-8_0.gif",
	"code":`?"\\^!5f10✽░4웃9:"
s=sin::_::cls()for i=0,799,8do
y=$(i+4)x=$i
if(x>147)x=0y=76+rnd(20)
p=x+1+3*cos(y/99)q=y+s(x/99-s(t()/8)/2)a=atan2(x-p,y-q)u=cos(a)v=s(a)
for j=4,9,.5do
b=s(a+t()/8-i/99)^2circ(x,y,s(j/9)*3*b,1-s(b/4-.1)*5)pset(x,y,2)x+=u
y+=v
end
poke4(i,p,q)end
flip()goto _`},
{"title":"Upgrade",
	"date":"2022-09-14",
	"desc":"You've been playing with blocks for eternity now. The colors seemed interesting at first but now the excitement is gone. Suddenly you attach one block to another. A new form emerges followed by a realization.",
	"art":"lego-12_1.gif",
	"code":`for i=0,23,8do?"⁶!5f55\\0"
c=i\\8*3?"◀³f▶⁶!5f113⬅️;9:♥2☉8",i,0,c+3
?"▶⁵cj◀⁵cc\`",i,3,c+2
?"◀⁵cj▶⁵c9,",i+3,3,c+1
end::_::for i=0,6^4do?"⁶!5f551"
z=i\\200y=14+i\\8%25x=14+i%8*2-y%2if(abs(x-21.4)+abs(y-21)<5-z)spr(z%3,x*3,y*3-z*6-z*cos(t()/9)^8*80,1,2)
end?"⁶1⁶cd"
goto _`},
{"title":"Vid-Phon",
	"date":"2022-08-01",
	"desc":`Hello?!" you ask again to no response. All you hear is the toxic rain on the booth and a 5-sec pinging interval draining your credits regardless of the connection.`,
	"art":"zx-pattern-2_0a.gif",
	"code":`function d(x,y,a,b)
u=6*sin(a)v=6*cos(a)p=sin(b)/12q=cos(b)/12
for j=0,105do
c=5
if(j<60)c+=({3,5,6,7})[j\\15+1]
line(x-u,y-v,x+u,y+v,c)
x+=p
y-=q
end
end
::_::
cls(1)
for k=-3,3do
for l=-3,3do
d(66+k*16,66+l*16,t()/3,((k+3)*6+(l+3))/36/4)
end
end
flip()
goto _`},
{"title":"Banner",
	"date":"2022-07-05",
	"desc":"The banner was sacred to them. It was a symbol of their home and values. But the territory took toll and they got tired. Banner got so dirty it was just a black rag. ",
	"art":"blackflag-7_0.gif",
	"code":`j=60pal({-14,2,-8,8,9,10},1)s=sin::_::cls(1)for b=32,127do
d=29+j/b*(9-s(t()))for a=(b%3+b\\j)*j,54do
k=a/j+.8e=0for i=2,5do
g=3^i/999e+=k/2^i*(s(g*b*8+s(g*a-j*t()*g)))end
x=d+e+a+s(b/j)*4y=b+e*4pset(x+3,y,k+e)?"#",x,y,0
end
line(pset(d,b,0),b+9,127,b+9,95/(127-b))end
flip()goto _`},
{"title":"Bifurcation",
	"date":"2022-02-17",
	"desc":"Officer, please. First, my client was clearly provoked. Second, spilling android's blood is not an aggravated assault but just a property damage.",
	"art":"smoke-9_0.gif",
	"code":`r=127s=sin
f={}for j=0,2^14do
x=j&r
y=j>>7sset(x,y,(s(x/r)+cos(y/r)+rnd(.2))*x/8)f[j\\8]={x=░}end::_::cls(1)d=6+s(t()/8)for p in all(f)do
if(p.x>r)p.x=0p.y=99+rnd(5)
a=sget(p.y,(p.x-t()*8)%128)/4p.x+=a*cos(p.y/d/6)+1p.y+=a*s(p.x/d/6)-pget(p.x,p.y)\\7pset(p.x,p.y,7)end
flip()goto _`},
 
{"title":"Witness",
	"date":"2022-02-08",
	"desc":"Enough waiting, all good people are asleep now. It's not the best night for this job but what can you do. Moon is watching but it won\'t tell a thing.",
	"art":"moon2-20_0.gif",
	"code":`?"\\^c0\\^!5f1000█🐱♪="
a=0s=sin::_::a+=1
for x=a%4-64,63,4do
for y=a%3-32,31,3do
g=.005e=0u=x-t()*8v=y
for i=1,8do
g*=2e+=5*.6^i*(s(3^i/999*u+s(g*v+t()/32)/2)+s(g*v*2+s(g*u)/3))end
if(x^2+y^2<199and(x+8)^2+(y+8)^2>360)e=7-e/3
e*=cos(y/128)pset(x+64,y+64,mid(e,7))
end
end
goto _`},
{"title":"Warm greetings",
	"date":"2022-02-02",
	"desc":"With polar caps gone and planet scale monsoons most of the central heating companies went out of business.",
	"art":"earth2-8_1.gif",
	"code":`function q(u,v)g=.6e=0for i=1,5do
g*=2e+=.6^i*(s(2^i*u+s(g*v)/2)+s(g*v*2+s(g*u)/4))end
return abs(e)end?"\\^c0\\^!5f100▒1⬇️😐<67█🐱░4웃9?7"
s=sin::_::d=rnd(2)b=.6+d/6a=rnd(.5)z=.03+s(b)*s(a)/99k=q(a,b)\\1*8+d+min(q(a*4,b*2+t()/99)*d*4,6)pset(64+cos(b)*s(a)/z,64+cos(a)/z,k)goto _`},
{"title":"Where were you in 2021?",
	"date":"2022-01-05",
	"desc":"",
	"art":"2021-8_3b.gif",
	"code":`q={}?"\^c02021",1
for i=0,4800do
x=i%60y=rnd(5)q[pget(x\\4,y)*#q+1]={x=35+x,y=y*4+29,u=0,v=0}end::_::?"\\^c0\^j9b>&lt;\\*b >&lt;"
for p in all(q)do
k=pget(p.x+p.u,p.y+1)&1p.u=k-rnd(k+k)p.v*=1-k
if(p.x&lt;t()*9)p.y=min(p.y+p.v,130+sin(p.x>>8)*42)p.v+=.4p.x+=p.u
pset(p.x,p.y,7)end
flip()goto _`},
{"title":"Cyclone",
	"date":"2021-12-09",
	"desc":"Yeah, this was unbearable place. I helped moving civies up north before the jungle reclaimed the city. What's strange there was no mega-cyclone since then.",
	"art":"blocks-7_0-optimized.gif",
	"code":`pal({5,6,7,-5,11,-6,-13,3,-5,9,10,-9,1,1,12},1)for i=0,7^5do
x=i%80y=i\\80b=8-abs(x%16-8)z=x\\16c=z+x\\8+1.2+rnd()
if(y&lt;b)c=z*3+3
sset(x,y-b/2+20-(4-z)^2,c)end::_::for y=-48,127,4do
srand(y-t()\\1*16)for x=-8,127,16do
spr((rnd(9)+1)&14,x+y\\4%2*8,y+t()*16%16,2,3)end
end
flip()goto _`},
{"title":"Old letters",
	"date":"2021-10-25",
	"desc":"What's the point of throwing them away if you remember every damn word?",
	"art":"bends-5_3.gif",
	"code":`pal({0,-15,1,-13,-4,12},1)::_::cls(3)srand()c=128d=0
for n=0,90do
if(c>127)c=-rnd(32)d+=10
l=9+rnd(23)p=sin(t()/4+l/99)^2+cos(t()/l*8)^2x,y=c,d
for j=0,l do
a=0v=0u=1
if(j>l*p)a=(j-l*p)/64v=(j+1)%2*sin(a)u=j%2*cos(a)
line(x,y,x+8,y-8,a*13+2)
x+=u
y+=v
end
c+=l+2end
flip()goto _`},
{"title":"Silicon-based lifeform",
	"date":"2021-08-11",
	"desc":"The last human is slain. It pings the base and gets no response. The task list is empty so it powers itself down.",
	"art":"cubes-2-12_2.gif",
	"code":`r=10q={}pal({cls(7),2,-8,8},1)for z=0,1999do
y=z\\7*20x=z\\7%2*r+z%7*20for u=0,r do
g=x+u
i=y-u+r
line(g-r,y+u+1,g-r,y+u+r,5)line(g,i,g,i+r,6)end
q[z]={x=rnd(z/4),y=-z}end::_::for p in all(q)do
k=(pget(p.x,p.y)-2)%3pset(p.x,p.y,k+2)p.y+=.4*(k-k*k)+1p.x+=k\\2*rnd(2)-k\\2end
goto _`},
{"title":"Inertia tensor",
	"date":"2021-08-01",
	"desc":"You cast the amber die and the elders watch it roll. Your fate will be sealed. But, hell, anything is better than a duel with the mutant.",
	"art":" glasscube-2-4_1.gif",
	"code":`pal({-12,4,-7,9,10},1)a=abs::_::u=t()cls(1)p=0for o=0,256do
srand(o\\4)m=o/256r=20/max(a(cos(m)),a(sin(m)))j=1+(m*4+1.5+u\\1)%4\\3*sin(u/2)^32*8m+=u/4x=cos(m)*r+64-a(cos(u/2))*9y=sin(m)*r/2+44
for z=y,y+32,a(p-x\\1)\\1do
pset(z,x,min(7,pget(z,x)+j+rnd(1.04)))end
p=x\\1end
flip()goto _`},
{"title":"Rooftop monologue",
	"date":"2021-07-05",
	"desc":"...because all that glitter will turn to dust.",
	"art":"dust-19_1.gif",
	"code":`q={}pal({0,1,-4,12},1)s=sin::_::cls()r=rnd
?\"  entropy\",1
m=r(40)n=r(5)
if(pget(m,n)>#q\\5^5)add(q,{x=m*3,y=n*3+60,a=r(m+n)*4,k=0})
if(t()<3)goto _
for p in all(q)do
if(p.a<4)p.x-=cos(p.k)p.y+=s(p.k)
p.k=p.k*.9+(s(s(p.x/99)+s(p.y/64)))/32p.a*=.99pset(p.x,p.y,p.a)end
flip()goto _`},
{"title":"Arthurian legends",
	"date":"2021-07-01",
	"desc":"You wade through the cold water for hours waiting for the Lady of the Lake. But instead of the Excalibur you get only rheumatism. (v2, fixed)",
	"art":"lake-6-final-fix_4.gif",
	"code":`pal({-15,1,-13,3,-5,11,-6,-9,10},1)::_::cls(1)srand()for j=0,255,5do
z=rnd()x=z*144-16y=(j-t()*16)&255for i=1,16do
a=sin(rnd()/5+t()/2+z+i/9)*i/500*(1+j/256)for h=1,3do
b=a-({15,-5,5})[h]/99d=4+h\\3*3u=x+d*sin(b)v=y-d*cos(b)line(x,y,u,v,i*j/512+2)end
x=u
y=v
end
end
flip()goto _`},
{"title":"Taffin' in the plain sight",
	"date":"2021-06-25",
	"desc":"What was that?! Hmm... just a wind I guess.",
	"art":"wind-turbine-3_0a.gif",
	"code":`pal({12,6,7,-6,-5,3},1)r=rnd::_::x=r(128)y=r(128)pset(x,y,sget(x,y))s=sin
if(r()>.1)goto _
g=y/376k=0for i=0,8do g*=2k+=.6^i*(s(s(g/2)/2-g*x/4/y)+s(g))end
k=min(1+y/99*(k^4),3)+y\\109*3
sset(x,y,k)for i=0,2 do
c=t()/4+i/3line(50+i,111,50,60,3)line(50+s(c)*9,60+cos(c)*25)end
goto _`},
{"title":"Paleo Future",
	"date":"2021-05-22",
	"desc":"Waves push you gently to the surface. You think about the future and instantly feel sad. You could cry a little but it's pointless. This ocean is already made of tears.",
	"art":"ammonite-9_1.gif",
	"code":`pal({-15,1,-4,12,7,6,-8},1)for l=0,32581do
i=l\\16/512j=l%16/16p=(1+i/4)^4.3u=p*sin(i)v=p*cos(i)sset(j*u+u+64,j*v+v+64,cos(i*16)^2+1-sin(j/2)*4)end::_::cls(1)
for r=0,99do
j=r%3i=r\\3circ(75-i-j*3,91+j*3+cos(i/24+t()+j/3)*i/20,3-r/40,7)end
?"O",64,90,5
spr(0,0,0,16,16)flip()goto _`},
{"title":"Shivers",
	"date":"2020-12-16",
	"desc":"You carefully lock the door and examine the sample under  a microscope. Cold shiver runs down your spine. The #parasite is fast and immune to everything. If it just wasn't your blood...",
	"art":"dust2-7_0.gif",
	"code":`pal({-16,-16,-14,-14,2,2,-8,-8,8,8},1)s=sin::_::c=t()%4
if(c&lt;.1)m=rnd(19)n=rnd(19)cls(10)
for i=0,7do
u=m+54v=n+54for j=0,c*64do
g=u/512h=v/512k=i/8for l=1,5do g*=2h*=2k+=.5^l*(s(s(g)+s(h))+s(g*2)+t()%32/(1+j/3))/2end
u+=cos(k)/2v-=s(k)/2pset(u,v,max(pget(u,v)-1))end
end
goto _`},
{"title":"Neon Jellyfish",
	"date":"2020-12-06",
	"desc":`Muffled hardbass beat wakes you up. You see huge aquarium with a single neon #jellyfish. "Is it artificial" you think. "How did it get there? Why am I handcuffed to the radiator?!"`,
	"art":"jf-11_7.gif ",
	"code":`c=cos::_::cls(3)m=t()r=0g=0h=0p=9+4*c(m)for b=0,1,.02do
pal(b*16,({-15,1,-4,12,6,7})[b*7\\1],1)g+=.004+c(b-m)*b/69r+=c(g)h-=sin(g)l=1+b\\.96*4for a=0,1,.02-b/99do
u=64+r*c(a)v=p+h+l*sin(a+b\\.99/2)
if(a&lt;.5)u=62+c(b-m+a\\.17/3)*9*b+a*9v=p+b*99
pset(u,v,pget(u,v)+l)end
end
flip()goto _`},
{"title":"XenOS",
	"date":"2020-11-28",
	"desc":"The ship looks dead. You gear up and try the the airlock. Panel turns on and shows some circles. Nah, you are tired, AI is tired. No time for another alien puzzle. Let's breach the hull.",
	"art":"concircles-7_2.gif ",
	"code":`m=127a={}for x=0,m+1,1>>8 do
y=x%.125<<8srand(x\\8+y\\8)sset(x,y,(rnd(1.75))\\1*(rnd(2)+y\\8*4+1))r=22+y\\8*10+y%8u=64+r*sin(x/m)v=64+r*cos(x/m)a[u\\1+v\\1*m]={x,y,u,v,y\\8%2*2-1}end
cls()::_::for k,c in pairs(a)do
pset(c[3],c[4],sget((c[1]+r*c[5])&127,c[2]))end
r+=1flip()goto _`},
{"title":"All-Poland Women's Strike",
	"date":"2020-11-16",
	"desc":"abortion law in Poland was tightened making ABORTION ILLEGAL even in case of severe fetus damage. Polish women declared war on government, church and bigotry.",
	"art":"flag-8_2.gif ",
	"code":`::_::cls(1)for b=0,127do
y=rnd(88)c=1u=64-y/4
if(y&gt;51)c=2.1
if(y&gt;64)u+=24c=1
sset(u+rnd(22*c-y/4),y+16,8)a=b/128+t()x=64+cos(a/4)*60y=32+sin(a/2)*8p=22-x/3q=59-y/3
for a=0,1,.02do pset(x+p*a,y+q*a,sget(b,a*128))end
end
line(x,y,64,192,4)line(x-1,y)flip()goto _`},
{"title":"In the land of BSOD",
	"date":"2020-11-13",
	"desc":"",
	"art":"xp-5_2b.gif",
	"code":`cls()fillp(▒\\1)pal({-4,12,6,7,7,7,-13,3,-5,-6},1)s=sin::_::x=rnd(128)m=78+s(x/192)*8y=rnd(96)w=x/6
if(y&lt;m)n=1w=x/2+t()*2
g=y/512k=0for i=0,6do g*=2k+=.6^i*(s(s(g/2)/2-g*w/y)+s(g))end
k=abs(k^3)+7
if(y&lt;m)k=min(k/4-7/4,4)+1
if(y&gt;93)k=1
pset(x,16+y,k+(k+.5)\\1*16)goto _`},
{"title":"Confetti",
	"date":"2020-11-05",
	"desc":`The uppercut is followed by a hook and all you see is a colorful confetti rain. "Did I win?", you think. No, you lost.`,
	"art":"fastconf-4_1.gif",
	"code":`p=0q=0s=0pal({-15,-14,-11,-10,-1,9,10,-9},1)r=rnd
::_::
if(s&lt;.2)srand(t())b=r()s=16
s*=.9k=s*cos(b)l=s*sin(b)
p+=k
q+=l
cls()srand()for d=1,9,.1do
x=(r(146)+p*d/8)%146-9y=(r(146)+q*d/8)%146-9a=d+t()*(1+r())/2u=d*cos(a)v=d*sin(a)line(x-u,y-v,x+k,y+l,d)line(x+u,y+v)end
flip()goto _`},
{"title":"Lobotomy",
	"date":"2020-11-01",
	"desc":"Removing the seeds from the pumpkin you are relieved that lobotomy is no longer performed. ",
	"art":"halloween-8_4.gif ",
	"code":`pal({-16,-14,-11,-12,4,-7,-2,9,10,-9,7},1)cls(1)s=sin::_::r=s(t())u=rnd()v=rnd()c=cos
a=u*.3+.6b=v*.3+.1z=2+s(a)*s(b)x=99*c(a)*s(b)y=(75+s(u*8)*8*s(v*2))*c(b)k=c(u/4+r/99)^2*7if((3-v*5&gt;c(u)and.6&lt;v)or(v&lt;c(u*5)/1.8and-c(u)&gt;.5and-s(u/2)/2&lt;v))k=r+v*7+5
pset(64+x/z,64-y/z,k)goto _`},
{"title":"Earth 2",
	"date":"2020-10-22",
	"desc":`Awoken from the cryosleep you experience a massive hangover. Project was a success, they said. But you wonder if "terraforming" eventually makes every planet uninhabitable.`,
	"art":"earth-12_3.gif",
	"code":`function p(u,v)g=v e=0for i=1,6 do
g*=2e+=.7^i*(s(g*u/v/2+s(g/2)/2)+s(g))end
return abs(e)end
pal({-15,1,-13,-4,12,6,7,1,-14,-12,3,4,9,15,7},1)s=sin::_::b=.6+rnd(.3)a=rnd(.5)y=cos(a)x=cos(b)*s(a)z=.03+s(b)*s(a)/99pset(64+x/z,64+y/z,1+p(a,b/3)\\1*8+min(p(a*2,b/2+t()/99)*6,6))goto _`},
{"title":"I grew up here",
	"date":"2020-09-21",
	"desc":"You played this tape too many times. Now even sitting still won't load the game. You try again and hold your breath... for 4.5 minutes.",
	"art":"i-grew-up-here-1_3.gif",
	"code":`r=rectfill
::_::
c=t()%8
if(c&lt;10)a,b,u,v,w=1,10,1,1,3
if(c&lt;3)a,b,u,v,w=8,12,5,0,3
for i=0,127 do 
line(0,i,128,i,flr(sin(i/127*40/(u+rnd(v))+t()*w)*.99+1)*(b-a)+a)
end
r(0,0,128,16,0)
r(0,112,128,128,0)
r(12,28,116,96,7)
if(c&gt;3)print("program: saboteur",14,32,0)
flip()goto _`},
{"title":"Not great, not terrible",
	"date":"2020-09-18",
	"desc":"You enter the reactor chamber to investigate strange clicking sounds. The sight of jumping control rods turns your stomach. This is pure techno but you can't dance.",
	"art":"hexagon-8_1-optimized.gif",
	"code":`pal({-15,1,-13,-4,12,2,4,-7},1)r=rnd::_::srand()for y=9,148,8 do
for x=0,128,28 do
h=4+sin(r()+t()/(r()+.5))k=4+r(1.1)\\1*5+r(1.2)for u=0,16 do
a=min(sin(-u/32)*6\\1,4)w=(u-x-14*(y\\8%2)-t()*30)%128v=y-h*4line(w,v,w,y+a,k-1-min(u\\4,1)-u\\13)line(w,v-a,w,v+a,k)end
end
end
flip()goto _`},
{"title":"Conscience",
	"date":"2020-08-03",
	"desc":"The summer rain lulled you to sleep. Then the storm came and a nightmare of someone in your room. Staring at you, wanting something, waiting. You wake up, or maybe you don't.",
	"art":"mortis-7_1-optimized.gif",
	"code":`r,g=rnd,circfill::_::k=r(1.05)\\1d=900o=128cls(1+k*9)for i=1,d do
?"/",(i-t()*48)%o,(sin(i^.5)*o+t()*o)%o,0
end
g(278,-824,d)g(278,952,d)g(928,64,d)for i=0,o do
x=5*min((i-22)^.4-2)+20-i/o
if(i&lt;20)x=3*i^.4
x+=r(2)i+=28pset(64+x,i,k)pset(63-x,i,k*9)end
?"+ +",58,38,k*7
flip()goto _`},
{"title":"Jack and the Beanstalk",
	"date":"2020-07-30",
	"desc":"You trade the cow for beans and plant them. As the beanstalk grows so does your ambition and yearning for wealth. The higher you climb the longer you will fall.",
	"art":"leaves-9_6a.gif",
	"code":`fillp(23130)pal({1,-13,3,-5,11,-6,10,7},1)::_::srand(cls(1))for y=0,120,3 do
b=9+sin(rnd()+t())a=rnd(.5)for n=0,b do
j=n/b/2m=5*sin(j)c=j*a*24u=60+b-a*9+32*j*cos(a)for p=u+m,u-m do
q=(n-y+t()*30)%132pset(p-2,q-4,c+2.5+(c+3)\\1*16)
if(pget(p,q)&gt;1)pset(p,q,0)end
end
end
flip()goto _`},
{"title":"Stormy Monday",
	"date":"2020-05-07",
	"desc":"The sea is far from calm. So are the things you wanted to think over. You stare blankly at the waves and your only conclusion is that it is best to head home.",
	"art":"sea-at-night-3_1-optimized.gif",
	"code":`pal({-15,1,-13,-4,12},1)z=0s=sin::_::fillp(23130)z+=1
for x=z%3,127,3 do
q=0line(x,0,x,64,1)for y=64+z%2,142,2 do
w=0l=.05u=x/y*24v=y*y/128
for k=2,3 do
l/=2w+=s(l*u/2+s(l*v/2)/2-l*z)+s(l*v+s(l*u)/4)end
k=5*s((q-w)/5+.2)^4
color(k+(k+.5)\\1*16)line(x,y-2-q*q)q=w
end
end
goto _`},
{"title":"Keep it Alive",
	"date":"2020-04-09",
	"desc":"a reminder that once the pump stops pumping it's... Game over, man. Game over!",
	"art":"heart-7_big.gif",
	"code":`pal({-16,-14,2,-8,8},1)fillp(23130)s=sin::_::cls()for p=.05,.4,.003 do
line()for q=.55,1,.05 do
g=85+s(p/.4-t())*9y=g*cos(p)g/=1.3+y/199x=g*cos(q)*s(p)+y/5j=s(p-.1)*s(q)k=j^2*5z=j+3u=x/z+64v=y/z+74
circ(u/4+34,v-20,2,k+(k+.5)\\1*16)circ(u/4+54,v-16,2)line(u,v)end
end
flip()goto _`},
{"title":"Nakatomi cleaner" ,
	"date":"2020-04-16",
	"desc":"You're done for today. Ascending slowly to the roof you watch sunset and see a chopper heading to plaza. But this is not your concern.",
	"art":"nakatomi-5_4-optimized.gif",
	"code":`r=16s=sin::_::for x=0,140,12 do
for y=-r,140 do
l=y+t()*30%r
if(y%r&lt;1)w=s(x/299+s(l/400))/19pal({-15,1,-13,-4,12,rect(x,l,x-13,l+r,1),7,fillp(23130),9,-7,4,2,0,0,0},1)v=s(w)
k=cos(w)^6*l/8line(x,l-v,x+9,l+v,k+r*flr(k+.5))end
end
?"▮",27,91
?"+\\nm",27,88
rect(r,99,41)flip()goto _`},
{"title":"Neo-noir",
	"date":"2020-04-12",
	"desc":"",
	"art":"easter-egg-5_1-optimized.gif",
	"code":`fillp(23130)s=sin::_::m=rnd()n=rnd()c=cos
i=flr(m*9)pal(i,({-16,-14,-12,4,-7,-1,9,9})[i],1)p=m/3+.1q=n/3+.6y=90*c(p)x=c(q)*s(p)*(64+y/8)z=3+s(q)*s(p)u=x/z+64v=y/z+64k=c(p-.3)*s(q+.1)^2*6
if(t()&lt;9)u-=9v=v/8+85k=0
if(t()&lt;8)k=min(n*9+2,8)u=m*128v=n*128
pset(u,v,k+flr(k+.5)*16)goto _`},
{"title":"Hourglass",
	"date":"2020-04-06",
	"desc":"After seeing hourglass half-full optimists should just reconsider.",
	"art":"hourglass-7_0-optimized.gif ",
	"code":`cls()j=1::_::d=rnd()b=-rnd()/2pal(j,({-15,1,-13,-4,12,6,7,7,7})[j],1)j=j%10+1h=1q=2p=4k=1l=0g=cos
if(j%2&lt;1)d*=.8h=0q=6k=.8l=14p=2
h+=h*5+g(d/2)^q*35z=2-h/99*sin(b)u=l*3+64+h/z*g(b)v=64+l/z+90/z*k*g(.1+d*.3)sset(u,v,g(b+.1)^p*8+l/4)pset(u+l*3,v,sget(u,v)/2+sget(u+42.3,v)/2)goto _`},
{"title":"Rear Window" ,
	"date":"2020-04-22",
	"desc":"",
	"art":"leaflike-4_3-optimized.gif",
	"code":`r=rnd::_::cls(1)srand()for j=0,74 do
pal(j%6+1,({-16,-14,-12,2,-8,8})[j%6+1],1)p=(r()+t()/2)%1
c=2+r(5.3)x=r(128)y=r(128)a=r()l=r(32)+32s=r(2)+3
for i=0,1,1/l do
b=a-sin(i+p)/20*(p-1)
if(i&gt;p*2-1 and i&lt;p*2)circfill(x+i*l*cos(b),y+i*l*sin(b),sin(i/2-p)*s,c)end
end
flip()goto _`},
{"title":"A mandatory coronation",
	"date":"2020-03-12",
	"desc":`The depressing idea of Jackpot from Gibson's "The Peripheral" stuck with me for years. It's a slow moving apocalypse of no particular reason.`,
	"art":"crown-5_1.gif",
	"code":`fillp(23130)s=sin::_::cls()
for i=500,1,-1 do
pal(i,({4,-7,9,9,10,-9,7,1})[i],1)a=i/500+.1z=.8*s(a)+2g=s((a+t()/5)%2-1)*3v=g+20/z+abs((i+t()*30)%30-15)/z+40u=80*cos(a)/z+64k=s(a+.1)^2*6+1
if(i&gt;200)k=k/2+1
line(u,v,u,60/z+40+g,k+flr(k+0.5)*16)pset(u,v,0)end
flip()goto _`},
{"title":"Romancing the Stone",
	"date":"2020-02-09",
	"desc":"Remember. Tough guy should always chop off heels with his machete. Villain should have a switchblade and wear sunglasses at night.",
	"art":"diam-6_3.gif",
	"code":`camera(-64,-74)fillp(23130)j=.0002s=sin::_::cls(1)for a=999,1,-1 do
pal(a,({-15,-13,3,-5,-6,-9,7})[a],1)a=a*j+.25j=-j
r=40-abs(s(3*a-t()/2))*6x=r*cos(a)z=-99-r*s(a)u=x/z*99v=1980/z
z=z*.8-19k=s(a+.1)^6*7k=k+flr(k+0.5)*16line(u,v,0,24,k)line(u,v,u*.8,2970/z,k+1)end
flip()goto _
`},
{"title":"Downtown",
	"date":"2020-02-03",
	"desc":`"AV, take me to Tyrell HQ"<br>
"Acknowledged. Destination Tyrell Corporation, ETA 16 minutes, taking off. Should I play Mozart?"<br>
"No, no. Wagner please."`,
	"art":"city-5_6a.gif",
	"code":`t=0pal(8,-3)l=line::_::for j=-1,7 do
r=flr(t/33-j)%9x=r%2*20srand(r)for i=0,3 do
w=flr(rnd(8))*2+8y=j*33+t%33k=1+(x%2)*4o=6+x%5-k
for z=0,2*w+rnd(w) do
y-=1s=(rnd(4)+1.2)l(x-w,y,x-w/2,y+w,flr(z%s/(s-1))*o+k)l(x+w,y)l(x+w,y,x+w/2,y-w,0)l(x-w,y)end
x+=w*2+5
end
end
flip()t+=1goto _`},
{"title":"The Masque of the Red Death",
	"date":"2020-02-21",
	"desc":"Who dares insult us with this blasphemous mockery? Seize him and unmask him - that we may know whom we have to hang at sunrise, from the battlements!",
	"art":"wind-10_4-optimized3.gif",
	"code":`a={}function f(p,x,y,m)x-=p.x
y-=p.y
d=x*x+y*y
p.x-=x/d*m-.3p.y-=y/d*m-.5
end::_::for i=1,999 do
if(t()&lt;1or rnd()&lt;.2)a[i]={x=rnd(105),y=rnd(96)}
p=a[i]f(p,40,64,40)f(p,88,64,40)f(p,64,80,4)f(p,64,84,8)f(p,0,128,50)f(p,128,128,65)pset(28+p.x*.6,20+p.y*.6,8)end
flip()cls()goto _`},
{"title":"Godlike repulsion",
	"date":"2020-02-16",
	"desc":"Did you ever trap a spider and watched it walk helplessly in Möbius strip of your hands? Feeling both superior and disgusted with it's shape?",
	"art":"spider-8_6-optimized.gif",
	"code":`p=64q=64s,c,n,l=sin,cos,rnd,line::_::cls(15)h=t()u=c(h/33)v=s(h/33)p+=u
q+=v
p%=128q%=128camera(-p,-q)circfill(-u*3,-v*3,3,0)for i=0,7 do
m=c(i/2)a=h/33+m/8+m*i/28n=c(flr(i/2)/2)a+=s(h)*n/40x=9*c(a)y=9*s(a)l(0,0,x,y)l(u,v,x,y)a+=(m+c(h)*n)/15l(x+5*c(a),y+5*s(a))end
flip()goto _`},
{"title":"Shattered illusions",
	"date":"2020-02-14",
	"desc":"Breaking a mirror isn't seven years of bad luck. After seven years the punishment is delivered by another mirror. <br>And it's forever.",
	"art":"break-5_1.gif",
	"code":`n=rnd::_::cls()srand()h=t()w=sin
for i=1,64 do
pal(i%6,({-15,1,-13,-4,12})[i%6],1)e=n(128)r=2+i/6
f=(n(128)+h*r*8)%128x=e+r*w(h+n())y=f-r*w(h+n())r/=2
c=e-r*w(h-n())d=f+r*w(h-n())k=abs(w(h+n())*r)+1u=(c-x)/33v=(d-y)/33
for q=0,33 do
line(e,f,x,y,k)x+=u
y+=v
end
end
flip()goto _`},
{"title":"Sturm und Drang",
	"date":"2020-02-13",
	"desc":"It's supposed to be snowing yet there was a storm two days ago. I feel something more sinister is coming.",
	"art":"storm-5_0.gif",
	"code":`o=128l=line::_::g=0r=rnd
srand()for i=0,699 do
j=i%5+1u=(r(o)-t()*19*j)%o
v=(r(o)+t()*39*j-9)%138l(u,v,u+j,v-j*2,1)end
srand(v)a=.7y=1x=u
for k=0,16,flr(r(1.06))do
c=6*cos(a)d=6*sin(a)a+=r(.1)-.05l(c+x,d+y,x,y,7)
if(r()&lt;.5)l(x+c*r(9),y+d*r(9))g=9
x+=c
y+=d
end
flip()cls(g)goto _`},
{"title":"Roll D20",
	"date":"2020-02-07",
	"desc":"A wireframe homage to Future Crew's 'SecondReality'",
	"art":"d20-5_2.gif ",
	"code":`function p(a,b,q)k,l=u,v
b+=t()/9
z=2+m*s(b)/99*s(a)
u=64+m*cos(b)/z*s(a)
v=o+n/z*cos(a)
if(q==nil)line(k,l,u,v)
end
s=sin
::_::cls()
m=80-s(t())*16
n=80+s(t())*16
o=50+s(t()/3)*40
for h=0,9 do
j=flr(h/5)/2
i=h%5/5
p(j,0,1)
p(.16+j,i)
p(.16+j,i+.2)
p(.34+j,i+.1)
end
flip()
goto _`},
{"title":"Orbiting over Solaris",
	"date":"2020-02-04",
	"desc":"Prolonged plasma watching may even be therapeutic. It's not only cost effective but also chemically neutral. It's a great effect. Even if its placebo effect.",
	"art":"gardner-accum-4_3a-optimized.gif",
	"code":`fillp(23130)z=0s=sin::_::z+=1
for x=z%3,127,3 do
pal(x%15+1,({-15,1,-13,-4,12,6,7,10,9,-7,4,2,1,-15})[x%15],1)for y=z%2,127,2 do
w=0u=.001v=.005k=3
for i=1,3 do    
u*=2v*=2k*=.7
w+=k*(s(u*x+s(v*y/2)/2+s(u*z/2))+s(v*y+s(v*x/2)/4))end
pset(x,y,w+flr(w+.5)*16)end
end
goto _`},
{"title":"nCoV",
	"date":"2020-01-09",
	"desc":"I have rare but recurring dream of nuclear holocaust. Not Sarah Connor nightmare with scorched skeletons, just distant flashes and overwhelming despair. Yet I was wrong.",
	"art":"corona-4a_1-optimized.gif",
	"code":`r=64o=circfill::_::cls()n=799
for j=0,1 do
for i=1,n do
p=80+flr(i%15/14)*20y=i*2/n-1s=p*(1-y*y)^.5w=i*.764+t()/9
if(j*w%1&lt;.5)then
y*=p
x=s*cos(w)z=s*sin(w)+200z=99/z
u=r+x*z
v=r+y*z
k=r+x*z/p*80l=r+y*z/p*80o(u,v,p/10-8,2)line(k,l,u,v)
end
if(i==j)o(r,r,40,0)
end
end
flip()goto _`},
{"title":"Blue Vertigo",
	"date":"2020-01-23",
	"desc":"Bathtub drain swirls are quite mesmerizing. I sometimes watch them hypnotized till water runs out. When I finally regain my consciousness I realize I am very cold.",
	"art":"tunnel-3_0a-optimized.gif",
	"code":`fillp(23130)s=sin::_::for r=16,128 do
pal(r%6,({-15,1,-13,-4,12,6,7})[r%6],1)j=16/r+t()/8p=64+r/4*cos(j)q=64+r/4*s(j)circ(p,q,30-r,0)g,h=p+r,q
for u=0,1,r/1400 do
w=s(u)k=abs(s(u*2+j+s(j))-w)*min(r/20,3)l=r-k
x=p+l*cos(u)y=q+w*l
line(g,h,x,y,k+flr(k+.5)*16)g,h=x,y
end
end
goto _`},
{"title":"Atom",
	"date":"2020-01-04",
	"desc":`As a kid I was once left with Geiger counter, radioactive source and instruction "Not to touch this". Well... I did my best to hear these clickety-clacks.`,
	"art":"atom-5_0-optimized2.gif",
	"code":`for i=1,9 do pal(i,-({14,12,-2,8,-8,2,7,1,-15})[i],1)end
cls(1)u=.11s=sin::_::c=cos
r=140u=rnd(.3)+.11v=rnd(.7)-.15k=8-abs(s(u*6+s(v)/4)-s(t()/5+v*8+s(u*6)/7))*4
if(v&gt;=.25)v+=.15r*=.6
p=r+k+48*c(v)z=p*s(u)/99+4x=p*c(u)/z+64y=70/z+48/z*s(v)
if(v&gt;.4)y=y*3+15
pset(x,y,k-k*v+1)goto _`},
{"title":"Hey moon",
	"date":"2019-12-26",
	"desc":"...It's just you and me tonight",
	"art":"moon-6_0-optimized2.gif",
	"code":`fillp(23130)o=128s=sin::_::x=flr(rnd(o))pal(x%14,({5,6,7,-15,-14,-12,4,1,2,-8,-2,-3,14,9})[x%14],1)y=rnd(o)c=abs(s((x/11+t())/9+s(y/o)/4)+s(y/33+s(x/o)/8))r=51/((x-64)^2+(y-64)^2)^.5g=mid(3-2/r,1.6)
if(r&gt;2)c=min(c+1.4,2)
if(r&gt;1.2)r=0
k=c*g+4*flr(r^8)pset(x,y,k+flr(k+.5)*16)goto _`},
{"title":"Swimming pool",
	"date":"2019-12-09",
	"desc":"Swimming pool always brings me good memories. I dived till my teeth hurt, played Wonder Boy and even instigated class mutiny once.",
	"art":"isopool-6_0-optimized.gif",
	"code":`f,s=flr,sin
function m(u,v,k)return(f(u/k)+f(v/k))%3-2*((s(u/19/k+s(v/9/k))+s(v/16/k-t()/4+s(u/6/k)))/2)^8 end::_::x=f(rnd(128))pal(x%16+1,({-15,1,-4,12,6,7})[x%16+1],1)y=rnd(128)j=sgn(63-x)c=m(x,y+x/2*j,16)+j%3
if(x+y*2&gt;192 and y*2&gt;x+64)c=m(x-y*2,y*2+x,32)+3
pset(x,y,c)goto _`},
{"title":"The Lighthouse",
	"date":"2019-12-03",
	"desc":"",
	"art":"lighthouse-5_0-optimized.gif",
	"code":`cls()t=0s=sin::_::t+=.01p=cos(t)/5k=32
for i=0,999 do
pal(i%6,({-15,1,-14,-3,13})[i%6],1)y=64-i%48w=2048/y
x=rnd(128)z=(x-99)*32/y+t*64l=max(s(z/50+s(w/99))+s(w/33-t/2+s(z/66)/4))pset(x,64-y,l*3.5+1)r=i/292*(s(t)+1)circ(k,32-r,r,7+s(t))k+=p
end
rectfill(30,32,33,99,0)flip()goto _`},
{"title":"Ghost",
	"date":"2019-10-22",
	"desc":`"Mom, can you leave the light on?"<br>
"..."<br>
"Mom?"<br>
"..."`,
	"art":"inktober-ghost-2_2.gif",
	"code":`r=circfill
s=sin
::_::
memset(0,0,8192)
cls()rectfill(36,9,90,88,1)
r(50,28,9,7)
r(52,27,8,1)
o=.005
for x=10,32,.5 do
z=8*x-64*t()w=s(o*z)
for y=0,96+s(w)*2,2 do
u=x+y/64*abs(s(.012*z+s(o*y/4)/2)+s(o*y*2+w/4))a=y*64+u
c=1+peek(a)
poke(a,c)
pset(u*3,8+y,c/3+5)end
end
flip()goto _`},
{"title":"Dragon",
	"date":"2019-10-13",
	"desc":"",
	"art":"inktober-dragon-2_2-optimized.gif",
	"code":`::_::cls(1)k=26l=64z=0
for x=4,94 do
q=x+16r=1-3*sin(x/186+.06)y=65+6*sin(x/211)*sin(x/96-t())line(q,y-r,q,y-r-x%4,3)circfill(q,y-1,r,6)
if(x&lt;6)line(12,y-2,20,y-x+2)line(14,y,20,y)pset(18,y-3,8)
if(y&lt;z)pset(15+x,y-r,7)
if((x-20)%40+x%8&gt;40)line(q,y,q+3,y+5,6)
z=y
end
flip()goto _`},
{"title":"Pattern",
	"date":"2019-10-11",
	"desc":"",
	"art":"inktober-pattern-4_1-optimized.gif ",
	"code":`t=0
for i=1,8 do pal(i,({1,2,-8,8,-2,9,10,-9})[i],1)end
::_::
cls()
t+=1
for y=0,128,24 do
for x=0,128,24 do
k,l=x,y
for j=0,64 do
a,b=k,l
k+=.6*(cos((a-32)/160)-sin((b+t)/160))
l+=.6*(sin((a+t)/160)-sin(b/160))
line(a,b,k,l,-sin(j/128)*9)
end
end
end
flip()goto _
`},
{"title":"Mindless",
	"date":"2019-10-02",
	"desc":"",
	"art":"inktober-mindless-2_2.gif",
	"code":`r,o,s=8,64,32
for y=0,127 do
for x=0,127 do
a=x+sin(y/64)*r
b=y-sin(x/64)*r
pset(x,y,abs(a%o-s)+abs(b%o-s))end
end::_::for i=0,15 do
k=0
if((t()*s-i)%16&lt;4)k=7
pal(i,k,1)end
flip()goto _`},
{"title":"Shadow of the Beast" ,
	"date":"2019-09-15",
	"desc":"homage to Amiga classic",
	"art":"sotb-4_2.gif",
	"code":`r=128::_::cls(6)srand()for y=0,15 do
pal(y,({-13,3,-5,11,-6,13,5,-10,15,7})[y],1)for x=0,r do
pset((x-t()*256/y)%r,r-y,2+y^2/49-rnd(1-y/32))end
end
for z=0,4 do
w=9+rnd(34)for y=0,w do
for x=y-w,w-y do
pset((x-y*y/40+z*30-t()*16)%r,113-y,x*y/w/5+9+rnd()/3)end
end
end
flip()goto _`},
{"title":"Over the garden wall" ,
	"date":"2019-09-11",
	"desc":"",
	"art":"brick-wall-7c_0-optimized2.gif",
	"code":`r,o=rnd,128
for y=32,o do
a=y%8pal(a,({-11,5,-10,3,-5})[a],1)for x=0,o+o do
c=min(3,a+r(2))
if(x%16&lt;2)c=x%2+1
sset(x-y+a,y,c)end
end::_::cls(2)spr(0,0,0,o,o)srand()for x=0,o do for y=r(5)+30,70+sin(x/30)*r(40),4 do
?4,x,y,1
?"+",x-r(4)-sin(t()/8+r()),y,4+r(2)
end
end
flip()goto _`},
{"title":"Evening summer breeze" ,
	"date":"2019-09-03",
	"desc":"(should be watched with your favorite ambient track loopped endlessly)",
	"art":"gard-grass-7_0-optimized2.gif",
	"code":`r,o,s,t={4,4,4,4,4,9,10,15,7},.015,sin,0
::_::
cls(2)
t+=1
srand()
for h=0,700 do
x=rnd(136)-4
y=h/5
z=x+t
c=s(.012*z+s(o*y/2)/2)+s(o*y+s(o*z/2)/4)
l=1+flr((c+2)*1.5);
c/=39
b=16
for i=1,3 do 
u=x+b*s(c)
v=y+b*s(c+.25)
b/=2
c*=2
line(x,y,u,v,r[l+i])
x,y=u,v
end
end
flip()
goto _`},
{"title":"These aren't the marching cubes (you're looking for)",
	"date":"2019-04-21",
	"desc":"",
	"art":"cubes-5_1-optimized.gif ",
	"code":`r,o,s=line,0,10
function c()for u=0,s do
g,h,i=x+u,y+u,y-u+s
r(g-s,h+1,g-s,h+s,5)r(g,i,g,i+s,6)r(g,i,g,h-s,7)r(x-u,i,x-u,h-s)end
end::_::o+=1
srand(flr(o/20))for z=0,63 do
j=flr(z/7)y=j*20-o%40 x=z%7*21+s*(j%2)c()x+=flr(o/s)%2*(o%s)y=y-o%20
if(rnd()&lt;.3)c()
end
flip()goto _`},
{"title":"Surfing on the sine waves",
	"date":"2019-04-10",
	"desc":"",
	"art":"voxel-1-sinewaves-6-optimized_0_opt.gif ",
	"code":`r,o,s,t,k=0,{0,5,6,7,15,14,8,2,4,9,10},sin,0,128::_::cls()t+=.2for y=81,k,8 do
for x=0,k do
j=5/(64-y)i,h,a,f,c=x*j/k,t/k+j,0,1,5
for n=1,2 do
f*=2c*=.7
a+=c*(s(f*i+s(f*h)/2)+s(f*h*2+s(f*i*2)/3))end
a=abs(a)c=y+a/j line(x,c,x,k,0)line(x-1,r,x,c,o[flr(a)])r=c
end
end
flip()goto _`},
{"title":"Untitled (Clouds)",
	"date":"2019-04-07",
	"desc":"",
	"art":"clouds-4_4-opt.gif",
	"code":`t,s=0,sin::_::t+=1
for l=0,8192 do
y=(l%96)x=rnd(128)u,v,a,f=(x-64)*64/(196-y*2)+t,t+y*y/64,0,.001
g=f
c=.5
for b=1,3 do
f*=2
g*=4
c*=.7
a+=c*s(f*u+s(g*v/2)/2)+c*s(g*v+s(g*u/2)/3)end
if(a&lt;.2)a=12
if(a&lt;.4)a=6
if(a&lt;5)a=7
pset(x,y,a)
if(a&lt;8)a-=1
pset(x,128-y/3,a%11)end
flip()goto _`},
{"title":"",
	"date":"",
	"desc":"",
	"art":"",
	"code":``},

];
	
codeart = codeart.filter(c=>c.title!="" && ["leaves","dragon's","symmetry","nest","schifahren","domino","neon je"].some(w=>c.title.toLowerCase().startsWith(w)));