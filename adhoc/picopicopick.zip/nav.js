function showone() {
    var c = codeart[0];
    if (!c) return;
    c.width = c.width ||256;
    c.height= c.height||256;
    var row   = $("<div class='row'></div>");
    var title = $("<div class='title'>"+c.title+"</div>");
    var date  = $("<div class='date'>"+c.date+"</div>");
    var desc  = $("<div class='desc'>"+c.desc+"</div>");
    var art   = $("<div class='art'><img width="+c.width+" height="+c.height+" src='"+c.art+"'></div>");
    var buts  = $("<div class='mbuttonscontainer'><a class='mbuttons mleftbut' href=# onclick='prev()'>&lt;&lt;&lt;</a><a class='mbuttons mrightbut' href=# onclick='next()'>&gt;&gt;&gt;</a></div>");
    var code  = $("<div class='code'></div>");
    var pre   = $("<pre><code class='language-lua'>"+c.code.replaceAll("<","&lt;").replaceAll(">","&gt;")+"</code></pre>");
    $(pre).fadeTo(0,0.5).hover(function(){$(this).fadeTo(0.2,1);},function(){$(this).fadeTo(0.2,0.5);}); 
    $(code).append(pre);
    $(row).append(c.art);
    $(row).append(title).append(date).append(desc);
    $(row).append(art);
    $(row).append(buts);
    $(row).append(code);
    $("div#content").html("");
    $("div#content").append(row);    
    Prism.highlightAll();
}

function prev() {
    codeart.unshift(codeart.pop());
    showone();
}

function next() {
    codeart.push(codeart.shift());
    showone();
}

$(document).keydown(function(e) {
  if(e.keyCode == 37) prev();
  else if(e.keyCode == 39) next();
});
    
$( document ).ready(()=>{
    showone();
});
